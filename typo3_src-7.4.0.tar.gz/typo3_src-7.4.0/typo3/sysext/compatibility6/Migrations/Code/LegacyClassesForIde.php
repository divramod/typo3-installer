<?php
die('Access denied');

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_About_Controller_AboutController extends \TYPO3\CMS\About\Controller\AboutController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_About_Domain_Model_Extension extends \TYPO3\CMS\About\Domain\Model\Extension {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_About_Domain_Repository_ExtensionRepository extends \TYPO3\CMS\About\Domain\Repository\ExtensionRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Aboutmodules_Controller_ModulesController extends \TYPO3\CMS\Aboutmodules\Controller\ModulesController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class AjaxLogin extends \TYPO3\CMS\Backend\AjaxLoginHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class clickMenu extends \TYPO3\CMS\Backend\ClickMenu\ClickMenu {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cli extends \TYPO3\CMS\Core\Controller\CommandLineController {}

/**
 * @deprecated since TYPO3 CMS 6.0, will be removed in TYPO3 CMS 8
 */
class t3lib_extMgm extends TYPO3\CMS\Core\Utility\ExtensionManagementUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_clipboard extends \TYPO3\CMS\Backend\Clipboard\Clipboard {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_transl8tools extends \TYPO3\CMS\Backend\Configuration\TranslationConfigurationProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TSparser extends \TYPO3\CMS\Core\TypoScript\Parser\TypoScriptParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TSparser_TSconfig extends \TYPO3\CMS\Backend\Configuration\TsConfigParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_matchCondition_backend extends \TYPO3\CMS\Backend\Configuration\TypoScript\ConditionMatching\ConditionMatcher {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_contextmenu_AbstractContextMenu extends \TYPO3\CMS\Backend\ContextMenu\AbstractContextMenu {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_contextmenu_AbstractDataProvider extends \TYPO3\CMS\Backend\ContextMenu\AbstractContextMenuDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_contextmenu_Action extends \TYPO3\CMS\Backend\ContextMenu\ContextMenuAction {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_contextmenu_ActionCollection extends \TYPO3\CMS\Backend\ContextMenu\ContextMenuActionCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_contextmenu_extdirect_ContextMenu extends \TYPO3\CMS\Backend\ContextMenu\Extdirect\AbstractExtdirectContextMenu {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_contextmenu_pagetree_DataProvider extends \TYPO3\CMS\Backend\ContextMenu\Pagetree\ContextMenuDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_contextmenu_pagetree_extdirect_ContextMenu extends \TYPO3\CMS\Backend\ContextMenu\Pagetree\Extdirect\ContextMenuConfiguration {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_contextmenu_renderer_Abstract extends \TYPO3\CMS\Backend\ContextMenu\Renderer\AbstractContextMenuRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TYPO3backend extends \TYPO3\CMS\Backend\Controller\BackendController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_backend_layout extends \TYPO3\CMS\Backend\Controller\BackendLayoutWizardController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_alt_clickmenu extends \TYPO3\CMS\Backend\Controller\ClickMenuController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_show_rechis extends \TYPO3\CMS\Backend\Controller\ContentElement\ElementHistoryController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_show_item extends \TYPO3\CMS\Backend\Controller\ContentElement\ElementInformationController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_move_el extends \TYPO3\CMS\Backend\Controller\ContentElement\MoveElementController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_db_new_content_el extends \TYPO3\CMS\Backend\Controller\ContentElement\NewContentElementController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_db_layout extends \TYPO3\CMS\Backend\Controller\PageLayoutController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_file_list extends \TYPO3\CMS\Filelist\Controller\FileListController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_dummy extends \TYPO3\CMS\Backend\Controller\DummyController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_alt_doc extends \TYPO3\CMS\Backend\Controller\EditDocumentController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_file_newfolder extends \TYPO3\CMS\Backend\Controller\File\CreateFolderController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_file_edit extends \TYPO3\CMS\Backend\Controller\File\EditFileController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TYPO3_tcefile extends \TYPO3\CMS\Backend\Controller\File\FileController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_file_upload extends \TYPO3\CMS\Backend\Controller\File\FileUploadController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_file_rename extends \TYPO3\CMS\Backend\Controller\File\RenameFileController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_alt_file_navframe extends \TYPO3\CMS\Backend\Controller\FileSystemNavigationFrameController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_listframe_loader extends \TYPO3\CMS\Backend\Controller\ListFrameLoaderController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_index extends \TYPO3\CMS\Backend\Controller\LoginController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_login_frameset extends \TYPO3\CMS\Backend\Controller\LoginFramesetController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_logout extends \TYPO3\CMS\Backend\Controller\LogoutController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_db_new extends \TYPO3\CMS\Backend\Controller\NewRecordController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_alt_db_navframe extends \TYPO3\CMS\Backend\Controller\PageTreeNavigationController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_tce_db extends \TYPO3\CMS\Backend\Controller\SimpleDataHandlerController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_add extends \TYPO3\CMS\Backend\Controller\Wizard\AddController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_colorpicker extends \TYPO3\CMS\Backend\Controller\Wizard\ColorpickerController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_edit extends \TYPO3\CMS\Backend\Controller\Wizard\EditController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_forms extends \TYPO3\CMS\Compatibility6\Controller\Wizard\FormsController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_list extends \TYPO3\CMS\Backend\Controller\Wizard\ListController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_rte extends \TYPO3\CMS\Backend\Controller\Wizard\RteController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_wizard_table extends \TYPO3\CMS\Backend\Controller\Wizard\TableController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_transferData extends \TYPO3\CMS\Backend\Form\DataPreprocessor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tceformsInlineHook extends \TYPO3\CMS\Backend\Form\Element\InlineElementHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEforms extends \TYPO3\CMS\Backend\Form\FormEngine {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_TCEforms_dbFileIconsHook extends \TYPO3\CMS\Backend\Form\DatabaseFileIconsHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEforms_Suggest extends \TYPO3\CMS\Backend\Form\Wizard\SuggestWizard {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEforms_Suggest_DefaultReceiver extends \TYPO3\CMS\Backend\Form\Wizard\SuggestWizardDefaultReceiver {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEforms_ValueSlider extends \TYPO3\CMS\Backend\Form\Wizard\ValueSliderWizard {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEforms_Flexforms extends \TYPO3\CMS\Backend\Form\FlexFormsHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tsfeBeUserAuth extends \TYPO3\CMS\Backend\FrontendBackendUserAuthentication {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class recordHistory extends \TYPO3\CMS\Backend\History\RecordHistory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class extDirect_DataProvider_State extends \TYPO3\CMS\Backend\InterfaceState\ExtDirect\DataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_extobjbase extends \TYPO3\CMS\Backend\Module\AbstractFunctionModule {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_SCbase extends \TYPO3\CMS\Backend\Module\BaseScriptClass {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_loadModules extends \TYPO3\CMS\Backend\Module\ModuleLoader {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Typo3_ModuleStorage extends \TYPO3\CMS\Backend\Module\ModuleStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_modSettings extends \TYPO3\CMS\Backend\ModuleSettings {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_recordList extends \TYPO3\CMS\Backend\RecordList\AbstractRecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TBE_browser_recordList extends \TYPO3\CMS\Backend\RecordList\ElementBrowserRecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_localRecordListGetTableHook extends \TYPO3\CMS\Backend\RecordList\RecordListGetTableHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_search_liveSearch extends \TYPO3\CMS\Backend\Search\LiveSearch\LiveSearch {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_search_liveSearch_queryParser extends \TYPO3\CMS\Backend\Search\LiveSearch\QueryParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_spritemanager_AbstractHandler extends \TYPO3\CMS\Backend\Sprite\AbstractSpriteHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_spritemanager_SimpleHandler extends \TYPO3\CMS\Backend\Sprite\SimpleSpriteHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_spritemanager_SpriteBuildingHandler extends \TYPO3\CMS\Backend\Sprite\SpriteBuildingHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_spritemanager_SpriteGenerator extends \TYPO3\CMS\Backend\Sprite\SpriteGenerator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_spritemanager_SpriteIconGenerator extends \TYPO3\CMS\Backend\Sprite\SpriteIconGeneratorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_SpriteManager extends \TYPO3\CMS\Backend\Sprite\SpriteManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class template extends \TYPO3\CMS\Backend\Template\DocumentTemplate {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class frontendDoc extends \TYPO3\CMS\Compatibility6\Template\FrontendDocumentTemplate {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface backend_cacheActionsHook extends \TYPO3\CMS\Backend\Toolbar\ClearCacheActionsHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_ExtDirect_AbstractExtJsTree extends \TYPO3\CMS\Backend\Tree\AbstractExtJsTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_AbstractTree extends \TYPO3\CMS\Backend\Tree\AbstractTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_AbstractDataProvider extends \TYPO3\CMS\Backend\Tree\AbstractTreeDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_AbstractStateProvider extends \TYPO3\CMS\Backend\Tree\AbstractTreeStateProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tree_ComparableNode extends \TYPO3\CMS\Backend\Tree\ComparableNodeInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tree_DraggableAndDropable extends \TYPO3\CMS\Backend\Tree\DraggableAndDropableNodeInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tree_LabelEditable extends \TYPO3\CMS\Backend\Tree\EditableNodeLabelInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_extdirect_Node extends \TYPO3\CMS\Backend\Tree\ExtDirectNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tree_pagetree_interfaces_CollectionProcessor extends \TYPO3\CMS\Backend\Tree\Pagetree\CollectionProcessorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_Commands extends \TYPO3\CMS\Backend\Tree\Pagetree\Commands {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_DataProvider extends \TYPO3\CMS\Backend\Tree\Pagetree\DataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_extdirect_Commands extends \TYPO3\CMS\Backend\Tree\Pagetree\ExtdirectTreeCommands {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_extdirect_Tree extends \TYPO3\CMS\Backend\Tree\Pagetree\ExtdirectTreeDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_Indicator extends \TYPO3\CMS\Backend\Tree\Pagetree\Indicator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_tree_pagetree_interfaces_IndicatorProvider extends \TYPO3\CMS\Backend\Tree\Pagetree\IndicatorProviderInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_Node extends \TYPO3\CMS\Backend\Tree\Pagetree\PagetreeNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_pagetree_NodeCollection extends \TYPO3\CMS\Backend\Tree\Pagetree\PagetreeNodeCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_Renderer_Abstract extends \TYPO3\CMS\Backend\Tree\Renderer\AbstractTreeRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Renderer_ExtJsJson extends \TYPO3\CMS\Backend\Tree\Renderer\ExtJsJsonTreeRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Renderer_UnorderedList extends \TYPO3\CMS\Backend\Tree\Renderer\UnorderedListTreeRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_SortedNodeCollection extends \TYPO3\CMS\Backend\Tree\SortedTreeNodeCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Node extends \TYPO3\CMS\Backend\Tree\TreeNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_NodeCollection extends \TYPO3\CMS\Backend\Tree\TreeNodeCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_RepresentationNode extends \TYPO3\CMS\Backend\Tree\TreeRepresentationNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_treeView extends \TYPO3\CMS\Backend\Tree\View\AbstractTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_browseTree extends \TYPO3\CMS\Backend\Tree\View\BrowseTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_folderTree extends \TYPO3\CMS\Backend\Tree\View\FolderTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_positionMap extends \TYPO3\CMS\Backend\Tree\View\PagePositionMap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_pageTree extends \TYPO3\CMS\Backend\Tree\View\PageTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_BEfunc extends \TYPO3\CMS\Backend\Utility\BackendUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_iconWorks extends \TYPO3\CMS\Backend\Utility\IconUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_BackendLayout extends \TYPO3\CMS\Backend\View\BackendLayoutView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class ModuleMenu extends \TYPO3\CMS\Backend\View\ModuleMenuView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_layout extends \TYPO3\CMS\Backend\View\PageLayoutView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_cms_layout_tt_content_drawItemHook extends \TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class webPageTree extends \TYPO3\CMS\Backend\View\PageTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_t3lib_thumbs extends \TYPO3\CMS\Backend\View\ThumbnailView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TYPO3Logo extends \TYPO3\CMS\Backend\View\LogoView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface cms_newContentElementWizardsHook extends \TYPO3\CMS\Backend\Wizard\NewContentElementWizardHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_extjs_ExtDirectRouter extends \TYPO3\CMS\Core\ExtDirect\ExtDirectRouter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_extjs_ExtDirectApi extends \TYPO3\CMS\Core\ExtDirect\ExtDirectApi {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_extjs_ExtDirectDebug extends \TYPO3\CMS\Core\ExtDirect\ExtDirectDebug {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_userAuth extends \TYPO3\CMS\Core\Authentication\AbstractUserAuthentication {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_beUserAuth extends \TYPO3\CMS\Core\Authentication\BackendUserAuthentication {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_cache_backend_AbstractBackend extends \TYPO3\CMS\Core\Cache\Backend\AbstractBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_ApcBackend extends \TYPO3\CMS\Core\Cache\Backend\ApcBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_cache_backend_Backend extends \TYPO3\CMS\Core\Cache\Backend\BackendInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_FileBackend extends \TYPO3\CMS\Core\Cache\Backend\FileBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_MemcachedBackend extends \TYPO3\CMS\Core\Cache\Backend\MemcachedBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_NullBackend extends \TYPO3\CMS\Core\Cache\Backend\NullBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_PdoBackend extends \TYPO3\CMS\Core\Cache\Backend\PdoBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_cache_backend_PhpCapableBackend extends \TYPO3\CMS\Core\Cache\Backend\PhpCapableBackendInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_RedisBackend extends \TYPO3\CMS\Core\Cache\Backend\RedisBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_TransientMemoryBackend extends \TYPO3\CMS\Core\Cache\Backend\TransientMemoryBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_backend_DbBackend extends \TYPO3\CMS\Core\Cache\Backend\Typo3DatabaseBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_Factory extends \TYPO3\CMS\Core\Cache\CacheFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_Manager extends \TYPO3\CMS\Core\Cache\CacheManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_Exception extends \TYPO3\CMS\Core\Cache\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_ClassAlreadyLoaded extends \TYPO3\CMS\Core\Cache\Exception\ClassAlreadyLoadedException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_DuplicateIdentifier extends \TYPO3\CMS\Core\Cache\Exception\DuplicateIdentifierException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_InvalidBackend extends \TYPO3\CMS\Core\Cache\Exception\InvalidBackendException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_InvalidCache extends \TYPO3\CMS\Core\Cache\Exception\InvalidCacheException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_InvalidData extends \TYPO3\CMS\Core\Cache\Exception\InvalidDataException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_exception_NoSuchCache extends \TYPO3\CMS\Core\Cache\Exception\NoSuchCacheException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_cache_frontend_AbstractFrontend extends \TYPO3\CMS\Core\Cache\Frontend\AbstractFrontend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_cache_frontend_Frontend extends \TYPO3\CMS\Core\Cache\Frontend\FrontendInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_frontend_PhpFrontend extends \TYPO3\CMS\Core\Cache\Frontend\PhpFrontend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_frontend_StringFrontend extends \TYPO3\CMS\Core\Cache\Frontend\StringFrontend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cache_frontend_VariableFrontend extends \TYPO3\CMS\Core\Cache\Frontend\VariableFrontend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cs extends \TYPO3\CMS\Core\Charset\CharsetConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_collection_AbstractRecordCollection extends \TYPO3\CMS\Core\Collection\AbstractRecordCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_Collection extends \TYPO3\CMS\Core\Collection\CollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_Editable extends \TYPO3\CMS\Core\Collection\EditableCollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_Nameable extends \TYPO3\CMS\Core\Collection\NameableCollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_Persistable extends \TYPO3\CMS\Core\Collection\PersistableCollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_RecordCollection extends \TYPO3\CMS\Core\Collection\RecordCollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_collection_RecordCollectionRepository extends \TYPO3\CMS\Core\Collection\RecordCollectionRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_collection_Sortable extends \TYPO3\CMS\Core\Collection\SortableCollectionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_collection_StaticRecordCollection extends \TYPO3\CMS\Core\Collection\StaticRecordCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_flexformtools extends \TYPO3\CMS\Core\Configuration\FlexForm\FlexFormTools {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_matchCondition_abstract extends \TYPO3\CMS\Core\Configuration\TypoScript\ConditionMatching\AbstractConditionMatcher {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_DB extends \TYPO3\CMS\Core\Database\DatabaseConnection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_DB_postProcessQueryHook extends \TYPO3\CMS\Core\Database\PostProcessQueryHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_DB_preProcessQueryHook extends \TYPO3\CMS\Core\Database\PreProcessQueryHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_PdoHelper extends \TYPO3\CMS\Core\Database\PdoHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_db_PreparedStatement extends \TYPO3\CMS\Core\Database\PreparedStatement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_queryGenerator extends \TYPO3\CMS\Core\Database\QueryGenerator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_fullsearch extends \TYPO3\CMS\Core\Database\QueryView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_refindex extends \TYPO3\CMS\Core\Database\ReferenceIndex {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_loadDBGroup extends \TYPO3\CMS\Core\Database\RelationHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_softrefproc extends \TYPO3\CMS\Core\Database\SoftReferenceIndex {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_sqlparser extends \TYPO3\CMS\Core\Database\SqlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_extTables_PostProcessingHook extends \TYPO3\CMS\Core\Database\TableConfigurationPostProcessingHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TCEmain extends \TYPO3\CMS\Core\DataHandling\DataHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_TCEmain_checkModifyAccessListHook extends \TYPO3\CMS\Core\DataHandling\DataHandlerCheckModifyAccessListHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_TCEmain_processUploadHook extends \TYPO3\CMS\Core\DataHandling\DataHandlerProcessUploadHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_browseLinksHook extends \TYPO3\CMS\Core\ElementBrowser\ElementBrowserHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_codec_JavaScriptEncoder extends \TYPO3\CMS\Core\Encoder\JavaScriptEncoder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_error_AbstractExceptionHandler extends \TYPO3\CMS\Core\Error\AbstractExceptionHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_DebugExceptionHandler extends \TYPO3\CMS\Core\Error\DebugExceptionHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_ErrorHandler extends \TYPO3\CMS\Core\Error\ErrorHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_error_ErrorHandlerInterface extends \TYPO3\CMS\Core\Error\ErrorHandlerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_Exception extends \TYPO3\CMS\Core\Error\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_error_ExceptionHandlerInterface extends \TYPO3\CMS\Core\Error\ExceptionHandlerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_error_http_AbstractClientErrorException extends \TYPO3\CMS\Core\Error\Http\AbstractClientErrorException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_error_http_AbstractServerErrorException extends \TYPO3\CMS\Core\Error\Http\AbstractServerErrorException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_BadRequestException extends \TYPO3\CMS\Core\Error\Http\BadRequestException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_ForbiddenException extends \TYPO3\CMS\Core\Error\Http\ForbiddenException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_PageNotFoundException extends \TYPO3\CMS\Core\Error\Http\PageNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_ServiceUnavailableException extends \TYPO3\CMS\Core\Error\Http\ServiceUnavailableException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_StatusException extends \TYPO3\CMS\Core\Error\Http\StatusException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_http_UnauthorizedException extends \TYPO3\CMS\Core\Error\Http\UnauthorizedException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_error_ProductionExceptionHandler extends \TYPO3\CMS\Core\Error\ProductionExceptionHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_exception extends \TYPO3\CMS\Core\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_formprotection_Abstract extends \TYPO3\CMS\Core\FormProtection\AbstractFormProtection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formprotection_BackendFormProtection extends \TYPO3\CMS\Core\FormProtection\BackendFormProtection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formprotection_DisabledFormProtection extends \TYPO3\CMS\Core\FormProtection\DisabledFormProtection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formprotection_InvalidTokenException extends \TYPO3\CMS\Core\FormProtection\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formprotection_Factory extends \TYPO3\CMS\Core\FormProtection\FormProtectionFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formprotection_InstallToolFormProtection extends \TYPO3\CMS\Core\FormProtection\InstallToolFormProtection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_frontendedit extends \TYPO3\CMS\Core\FrontendEditing\FrontendEditingController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_parsehtml extends \TYPO3\CMS\Core\Html\HtmlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_parsehtml_proc extends \TYPO3\CMS\Core\Html\RteHtmlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TYPO3AJAX extends \TYPO3\CMS\Core\Http\AjaxRequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_http_Request extends \TYPO3\CMS\Core\Http\HttpRequest {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_http_observer_Download extends \TYPO3\CMS\Core\Http\Observer\Download {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_stdGraphic extends \TYPO3\CMS\Core\Imaging\GraphicalFunctions {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_admin extends \TYPO3\CMS\Core\Integrity\DatabaseIntegrityCheck {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_exception_FileNotFound extends \TYPO3\CMS\Core\Localization\Exception\FileNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_exception_InvalidParser extends \TYPO3\CMS\Core\Localization\Exception\InvalidParserException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_exception_InvalidXmlFile extends \TYPO3\CMS\Core\Localization\Exception\InvalidXmlFileException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_Store extends \TYPO3\CMS\Core\Localization\LanguageStore {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_Locales extends \TYPO3\CMS\Core\Localization\Locales {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_Factory extends \TYPO3\CMS\Core\Localization\LocalizationFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_l10n_parser_AbstractXml extends \TYPO3\CMS\Core\Localization\Parser\AbstractXmlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_l10n_parser extends \TYPO3\CMS\Core\Localization\Parser\LocalizationParserInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_parser_Llphp extends \TYPO3\CMS\Core\Localization\Parser\LocallangArrayParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_parser_Llxml extends \TYPO3\CMS\Core\Localization\Parser\LocallangXmlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_l10n_parser_Xliff extends \TYPO3\CMS\Core\Localization\Parser\XliffParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_lock extends \TYPO3\CMS\Core\Locking\Locker {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_mail_Mailer extends \TYPO3\CMS\Core\Mail\Mailer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_mail_MailerAdapter extends \TYPO3\CMS\Core\Mail\MailerAdapterInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_mail_Message extends \TYPO3\CMS\Core\Mail\MailMessage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_mail_MboxTransport extends \TYPO3\CMS\Core\Mail\MboxTransport {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_mail_Rfc822AddressesParser extends \TYPO3\CMS\Core\Mail\Rfc822AddressesParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_message_AbstractMessage extends \TYPO3\CMS\Core\Messaging\AbstractMessage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_message_AbstractStandaloneMessage extends \TYPO3\CMS\Core\Messaging\AbstractStandaloneMessage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_message_ErrorpageMessage extends \TYPO3\CMS\Core\Messaging\ErrorpageMessage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_FlashMessage extends \TYPO3\CMS\Core\Messaging\FlashMessage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_FlashMessageQueue extends \TYPO3\CMS\Core\Messaging\FlashMessageQueue {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_PageRenderer extends \TYPO3\CMS\Core\Page\PageRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_Registry extends \TYPO3\CMS\Core\Registry {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_Compressor extends \TYPO3\CMS\Core\Resource\ResourceCompressor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_svbase extends \TYPO3\CMS\Core\Service\AbstractService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_Singleton extends \TYPO3\CMS\Core\SingletonInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TimeTrackNull extends \TYPO3\CMS\Core\TimeTracker\NullTimeTracker {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_timeTrack extends \TYPO3\CMS\Core\TimeTracker\TimeTracker {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class t3lib_tree_Tca_AbstractTcaTreeDataProvider extends \TYPO3\CMS\Core\Tree\TableConfiguration\AbstractTableConfigurationTreeDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Tca_DatabaseTreeDataProvider extends \TYPO3\CMS\Core\Tree\TableConfiguration\DatabaseTreeDataProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Tca_DatabaseNode extends \TYPO3\CMS\Core\Tree\TableConfiguration\DatabaseTreeNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Tca_ExtJsArrayRenderer extends \TYPO3\CMS\Core\Tree\TableConfiguration\ExtJsArrayTreeRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Tca_TcaTree extends \TYPO3\CMS\Core\Tree\TableConfiguration\TableConfigurationTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tree_Tca_DataProviderFactory extends \TYPO3\CMS\Core\Tree\TableConfiguration\TreeDataProviderFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tsStyleConfig extends \TYPO3\CMS\Core\TypoScript\ConfigurationForm {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_tsparser_ext extends \TYPO3\CMS\Core\TypoScript\ExtendedTemplateService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_TStemplate extends \TYPO3\CMS\Core\TypoScript\TemplateService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Array extends \TYPO3\CMS\Core\Utility\ArrayUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Client extends \TYPO3\CMS\Core\Utility\ClientUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_exec extends \TYPO3\CMS\Core\Utility\CommandUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Command extends \TYPO3\CMS\Core\Utility\CommandUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Debug extends \TYPO3\CMS\Core\Utility\DebugUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_diff extends \TYPO3\CMS\Core\Utility\DiffUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_basicFileFunctions extends \TYPO3\CMS\Core\Utility\File\BasicFileUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_extFileFunctions extends \TYPO3\CMS\Core\Utility\File\ExtendedFileUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_extFileFunctions_processDataHook extends \TYPO3\CMS\Core\Utility\File\ExtendedFileUtilityProcessDataHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_div extends \TYPO3\CMS\Core\Utility\GeneralUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Http extends \TYPO3\CMS\Core\Utility\HttpUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Mail extends \TYPO3\CMS\Core\Utility\MailUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Math extends \TYPO3\CMS\Core\Utility\MathUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Monitor extends \TYPO3\CMS\Core\Utility\MonitorUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Path extends \TYPO3\CMS\Core\Utility\PathUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_PhpOptions extends \TYPO3\CMS\Core\Utility\PhpOptionsUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_VersionNumber extends \TYPO3\CMS\Core\Utility\VersionNumberUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_view_help extends \TYPO3\CMS\Cshmanual\Controller\HelpModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cssstyledcontent_pi1 extends \TYPO3\CMS\CssStyledContent\Controller\CssStyledContentController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_dbal_module1 extends \TYPO3\CMS\Dbal\Controller\ModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_dbal_querycache extends \TYPO3\CMS\Dbal\QueryCache {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class ux_t3lib_DB extends \TYPO3\CMS\Dbal\Database\DatabaseConnection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class ux_t3lib_sqlparser extends \TYPO3\CMS\Dbal\Database\SqlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class ux_localRecordList extends \TYPO3\CMS\Dbal\RecordList\DatabaseRecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Command_HelpCommandController extends \TYPO3\CMS\Extbase\Command\HelpCommandController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Configuration_AbstractConfigurationManager extends \TYPO3\CMS\Extbase\Configuration\AbstractConfigurationManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_BackendConfigurationManager extends \TYPO3\CMS\Extbase\Configuration\BackendConfigurationManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_ConfigurationManager extends \TYPO3\CMS\Extbase\Configuration\ConfigurationManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Configuration_ConfigurationManagerInterface extends \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception extends \TYPO3\CMS\Extbase\Configuration\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception_ContainerIsLocked extends \TYPO3\CMS\Extbase\Configuration\Exception\ContainerIsLockedException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception_InvalidConfigurationType extends \TYPO3\CMS\Extbase\Configuration\Exception\InvalidConfigurationTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception_NoSuchFile extends \TYPO3\CMS\Extbase\Configuration\Exception\NoSuchFileException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception_NoSuchOption extends \TYPO3\CMS\Extbase\Configuration\Exception\NoSuchOptionException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_Exception_ParseError extends \TYPO3\CMS\Extbase\Configuration\Exception\ParseErrorException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Configuration_FrontendConfigurationManager extends \TYPO3\CMS\Extbase\Configuration\FrontendConfigurationManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Core_Bootstrap extends \TYPO3\CMS\Extbase\Core\Bootstrap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Core_BootstrapInterface extends \TYPO3\CMS\Extbase\Core\BootstrapInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Domain_Model_AbstractFileCollection extends \TYPO3\CMS\Extbase\Domain\Model\AbstractFileCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Domain_Model_AbstractFileFolder extends \TYPO3\CMS\Extbase\Domain\Model\AbstractFileFolder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_BackendUser extends \TYPO3\CMS\Extbase\Domain\Model\BackendUser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_BackendUserGroup extends \TYPO3\CMS\Extbase\Domain\Model\BackendUserGroup {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_Category extends \TYPO3\CMS\Extbase\Domain\Model\Category {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_File extends \TYPO3\CMS\Extbase\Domain\Model\File {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_FileMount extends \TYPO3\CMS\Extbase\Domain\Model\FileMount {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_FileReference extends \TYPO3\CMS\Extbase\Domain\Model\FileReference {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_Folder extends \TYPO3\CMS\Extbase\Domain\Model\Folder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_FolderBasedFileCollection extends \TYPO3\CMS\Extbase\Domain\Model\FolderBasedFileCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_FrontendUser extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_FrontendUserGroup extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUserGroup {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Model_StaticFileCollection extends \TYPO3\CMS\Extbase\Domain\Model\StaticFileCollection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_BackendUserRepository extends \TYPO3\CMS\Extbase\Domain\Repository\BackendUserGroupRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_BackendUserGroupRepository extends \TYPO3\CMS\Extbase\Domain\Repository\BackendUserGroupRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_CategoryRepository extends \TYPO3\CMS\Extbase\Domain\Repository\CategoryRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_FileMountRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FileMountRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_FrontendUserGroupRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserGroupRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Domain_Repository_FrontendUserRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_DomainObject_AbstractDomainObject extends \TYPO3\CMS\Extbase\DomainObject\AbstractDomainObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_DomainObject_AbstractEntity extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_DomainObject_DomainObjectInterface extends \TYPO3\CMS\Extbase\DomainObject\DomainObjectInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_DomainObject_AbstractValueObject extends \TYPO3\CMS\Extbase\DomainObject\AbstractValueObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Error_Error extends \TYPO3\CMS\Extbase\Error\Error {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Error_Message extends \TYPO3\CMS\Extbase\Error\Message {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Error_Notice extends \TYPO3\CMS\Extbase\Error\Notice {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Error_Result extends \TYPO3\CMS\Extbase\Error\Result {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Error_Warning extends \TYPO3\CMS\Extbase\Error\Warning {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Exception extends \TYPO3\CMS\Extbase\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_Command extends \TYPO3\CMS\Extbase\Mvc\Cli\Command {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_CommandArgumentDefinition extends \TYPO3\CMS\Extbase\Mvc\Cli\CommandArgumentDefinition {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_CommandManager extends \TYPO3\CMS\Extbase\Mvc\Cli\CommandManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_Request extends \TYPO3\CMS\Extbase\Mvc\Cli\Request {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_RequestBuilder extends \TYPO3\CMS\Extbase\Mvc\Cli\RequestBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_RequestHandler extends \TYPO3\CMS\Extbase\Mvc\Cli\RequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_CLI_Response extends \TYPO3\CMS\Extbase\Mvc\Cli\Response {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_MVC_Controller_AbstractController extends \TYPO3\CMS\Extbase\Mvc\Controller\AbstractController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_ActionController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_Argument extends \TYPO3\CMS\Extbase\Mvc\Controller\Argument {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_Arguments extends \TYPO3\CMS\Extbase\Mvc\Controller\Arguments {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_CommandController extends \TYPO3\CMS\Extbase\Mvc\Controller\CommandController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_Controller_CommandControllerInterface extends \TYPO3\CMS\Extbase\Mvc\Controller\CommandControllerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_ControllerContext extends \TYPO3\CMS\Extbase\Mvc\Controller\ControllerContext {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_Controller_ControllerInterface extends \TYPO3\CMS\Extbase\Mvc\Controller\ControllerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_Exception_RequiredArgumentMissingException extends \TYPO3\CMS\Extbase\Mvc\Controller\Exception\RequiredArgumentMissingException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Controller_MvcPropertyMappingConfiguration extends \TYPO3\CMS\Extbase\Mvc\Controller\MvcPropertyMappingConfiguration {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Dispatcher extends \TYPO3\CMS\Extbase\Mvc\Dispatcher {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception extends \TYPO3\CMS\Extbase\Mvc\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_AmbiguousCommandIdentifier extends \TYPO3\CMS\Extbase\Mvc\Exception\AmbiguousCommandIdentifierException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_Command extends \TYPO3\CMS\Extbase\Mvc\Exception\CommandException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InfiniteLoop extends \TYPO3\CMS\Extbase\Mvc\Exception\InfiniteLoopException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidActionName extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidActionNameException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidArgumentMixing extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidArgumentMixingException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidArgumentName extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidArgumentNameException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidArgumentType extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidArgumentTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidArgumentValue extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidArgumentValueException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidCommandIdentifier extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidCommandIdentifierException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidController extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidControllerException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidControllerName extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidControllerNameException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidExtensionName extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidExtensionNameException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidMarker extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidMarkerException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidOrNoRequestHash extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidOrNoRequestHashException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidRequestMethod extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidRequestMethodException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidRequestType extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidRequestTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidTemplateResource extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidTemplateResourceException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidUriPattern extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidUriPatternException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_InvalidViewHelper extends \TYPO3\CMS\Extbase\Mvc\Exception\InvalidViewHelperException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_NoSuchAction extends \TYPO3\CMS\Extbase\Mvc\Exception\NoSuchActionException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_NoSuchArgument extends \TYPO3\CMS\Extbase\Mvc\Exception\NoSuchArgumentException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_NoSuchCommand extends \TYPO3\CMS\Extbase\Mvc\Exception\NoSuchCommandException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_NoSuchController extends \TYPO3\CMS\Extbase\Mvc\Exception\NoSuchControllerException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_RequiredArgumentMissing extends \TYPO3\CMS\Extbase\Mvc\Exception\RequiredArgumentMissingException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_StopAction extends \TYPO3\CMS\Extbase\Mvc\Exception\StopActionException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Exception_UnsupportedRequestType extends \TYPO3\CMS\Extbase\Mvc\Exception\UnsupportedRequestTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Request extends \TYPO3\CMS\Extbase\Mvc\Request {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_RequestHandlerInterface extends \TYPO3\CMS\Extbase\Mvc\RequestHandlerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_RequestHandlerResolver extends \TYPO3\CMS\Extbase\Mvc\RequestHandlerResolver {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_RequestInterface extends \TYPO3\CMS\Extbase\Mvc\RequestInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Response extends \TYPO3\CMS\Extbase\Mvc\Response {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_ResponseInterface extends \TYPO3\CMS\Extbase\Mvc\ResponseInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_MVC_View_AbstractView extends \TYPO3\CMS\Extbase\Mvc\View\AbstractView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_View_EmptyView extends \TYPO3\CMS\Extbase\Mvc\View\EmptyView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_View_NotFoundView extends \TYPO3\CMS\Extbase\Mvc\View\NotFoundView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_MVC_View_ViewInterface extends \TYPO3\CMS\Extbase\Mvc\View\ViewInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_MVC_Web_AbstractRequestHandler extends \TYPO3\CMS\Extbase\Mvc\Web\AbstractRequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_BackendRequestHandler extends \TYPO3\CMS\Extbase\Mvc\Web\BackendRequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_FrontendRequestHandler extends \TYPO3\CMS\Extbase\Mvc\Web\FrontendRequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_Request extends \TYPO3\CMS\Extbase\Mvc\Web\Request {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_RequestBuilder extends \TYPO3\CMS\Extbase\Mvc\Web\RequestBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_Response extends \TYPO3\CMS\Extbase\Mvc\Web\Response {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_MVC_Web_Routing_UriBuilder extends \TYPO3\CMS\Extbase\Mvc\Web\Routing\UriBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_ClassInfo extends \TYPO3\CMS\Extbase\Object\Container\ClassInfo {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_ClassInfoCache extends \TYPO3\CMS\Extbase\Object\Container\ClassInfoCache {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_ClassInfoFactory extends \TYPO3\CMS\Extbase\Object\Container\ClassInfoFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_Container extends \TYPO3\CMS\Extbase\Object\Container\Container {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_Exception_CannotInitializeCacheException extends \TYPO3\CMS\Extbase\Object\Container\Exception\CannotInitializeCacheException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_Exception_TooManyRecursionLevelsException extends \TYPO3\CMS\Extbase\Object\Container\Exception\TooManyRecursionLevelsException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Container_Exception_UnknownObjectException extends \TYPO3\CMS\Extbase\Object\Container\Exception\UnknownObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Exception extends \TYPO3\CMS\Extbase\Object\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Exception_CannotBuildObject extends \TYPO3\CMS\Extbase\Object\Exception\CannotBuildObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Exception_CannotReconstituteObject extends \TYPO3\CMS\Extbase\Object\Exception\CannotReconstituteObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_Exception_WrongScope extends \TYPO3\CMS\Extbase\Object\Exception\WrongScopeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_InvalidClass extends \TYPO3\CMS\Extbase\Object\InvalidClassException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_InvalidObjectConfiguration extends \TYPO3\CMS\Extbase\Object\InvalidObjectConfigurationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_InvalidObject extends \TYPO3\CMS\Extbase\Object\InvalidObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_ObjectAlreadyRegistered extends \TYPO3\CMS\Extbase\Object\ObjectAlreadyRegisteredException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_ObjectManager extends \TYPO3\CMS\Extbase\Object\ObjectManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Object_ObjectManagerInterface extends \TYPO3\CMS\Extbase\Object\ObjectManagerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_UnknownClass extends \TYPO3\CMS\Extbase\Object\UnknownClassException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_UnknownInterface extends \TYPO3\CMS\Extbase\Object\UnknownInterfaceException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Object_UnresolvedDependencies extends \TYPO3\CMS\Extbase\Object\UnresolvedDependenciesException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Backend extends \TYPO3\CMS\Extbase\Persistence\Generic\Backend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_BackendInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\BackendInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_CleanStateNotMemorized extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\CleanStateNotMemorizedException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_IllegalObjectType extends \TYPO3\CMS\Extbase\Persistence\Exception\IllegalObjectTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_InvalidClass extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\InvalidClassException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_InvalidNumberOfConstraints extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\InvalidNumberOfConstraintsException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_InvalidPropertyType extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\InvalidPropertyTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_MissingBackend extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\MissingBackendException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_RepositoryException extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\RepositoryException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_TooDirty extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\TooDirtyException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_UnexpectedTypeException extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\UnexpectedTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_UnknownObject extends \TYPO3\CMS\Extbase\Persistence\Exception\UnknownObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_UnsupportedMethod extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\UnsupportedMethodException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_UnsupportedOrder extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\UnsupportedOrderException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Exception_UnsupportedRelation extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\UnsupportedRelationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Generic_Exception_InconsistentQuerySettings extends \TYPO3\CMS\Extbase\Persistence\Generic\Exception\InconsistentQuerySettingsException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_LazyLoadingProxy extends \TYPO3\CMS\Extbase\Persistence\Generic\LazyLoadingProxy {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_LazyObjectStorage extends \TYPO3\CMS\Extbase\Persistence\Generic\LazyObjectStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_LoadingStrategyInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\LoadingStrategyInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Mapper_ColumnMap extends \TYPO3\CMS\Extbase\Persistence\Generic\Mapper\ColumnMap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Mapper_DataMap extends \TYPO3\CMS\Extbase\Persistence\Generic\Mapper\DataMap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Mapper_DataMapFactory extends \TYPO3\CMS\Extbase\Persistence\Generic\Mapper\DataMapFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Mapper_DataMapper extends \TYPO3\CMS\Extbase\Persistence\Generic\Mapper\DataMapper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_ObjectMonitoringInterface extends \TYPO3\CMS\Extbase\Persistence\ObjectMonitoringInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_ObjectStorage extends \TYPO3\CMS\Extbase\Persistence\ObjectStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Manager extends \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_PersistenceManagerInterface extends \TYPO3\CMS\Extbase\Persistence\PersistenceManagerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_ManagerInterface extends \TYPO3\CMS\Extbase\Persistence\PersistenceManagerInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_PropertyType extends \TYPO3\CMS\Extbase\Persistence\Generic\PropertyType {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_AndInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\AndInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_BindVariableValue extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\BindVariableValue {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_BindVariableValueInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\BindVariableValueInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_Comparison extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\Comparison {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_ComparisonInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\ComparisonInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_ConstraintInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\ConstraintInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_DynamicOperandInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\DynamicOperandInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_EquiJoinCondition extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\EquiJoinCondition {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_EquiJoinConditionInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\EquiJoinConditionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_Join extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\Join {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_JoinConditionInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\JoinConditionInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_JoinInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\JoinInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_LogicalAnd extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\LogicalAnd {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_LogicalNot extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\LogicalNot {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_LogicalOr extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\LogicalOr {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_LowerCase extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\LowerCase {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_LowerCaseInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\LowerCaseInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_NotInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\NotInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_OperandInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\OperandInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_Ordering extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\Ordering {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_OrderingInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\OrderingInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_OrInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\OrInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_PropertyValue extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\PropertyValue {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_PropertyValueInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\PropertyValueInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_QueryObjectModelFactory extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\QueryObjectModelFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_Selector extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\Selector {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_SelectorInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\SelectorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_SourceInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\SourceInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_Statement extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\Statement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_StaticOperandInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\StaticOperandInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QOM_UpperCase extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\UpperCase {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QOM_UpperCaseInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Qom\UpperCaseInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Query extends \TYPO3\CMS\Extbase\Persistence\Generic\Query {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QueryFactory extends \TYPO3\CMS\Extbase\Persistence\Generic\QueryFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QueryFactoryInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\QueryFactoryInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QueryInterface extends \TYPO3\CMS\Extbase\Persistence\QueryInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_QueryResult extends \TYPO3\CMS\Extbase\Persistence\Generic\QueryResult {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QueryResultInterface extends \TYPO3\CMS\Extbase\Persistence\QueryResultInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_QuerySettingsInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\QuerySettingsInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Repository extends \TYPO3\CMS\Extbase\Persistence\Repository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_RepositoryInterface extends \TYPO3\CMS\Extbase\Persistence\RepositoryInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Session extends \TYPO3\CMS\Extbase\Persistence\Generic\Session {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Persistence_Storage_BackendInterface extends \TYPO3\CMS\Extbase\Persistence\Generic\Storage\BackendInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Storage_Exception_BadConstraint extends \TYPO3\CMS\Extbase\Persistence\Generic\Storage\Exception\BadConstraintException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Storage_Exception_SqlError extends \TYPO3\CMS\Extbase\Persistence\Generic\Storage\Exception\SqlErrorException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Storage_Typo3DbBackend extends \TYPO3\CMS\Extbase\Persistence\Generic\Storage\Typo3DbBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Persistence_Typo3QuerySettings extends \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception extends \TYPO3\CMS\Extbase\Property\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_DuplicateObjectException extends \TYPO3\CMS\Extbase\Property\Exception\DuplicateObjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_DuplicateTypeConverterException extends \TYPO3\CMS\Extbase\Property\Exception\DuplicateTypeConverterException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_FormatNotSupportedException extends \TYPO3\CMS\Extbase\Property\Exception\FormatNotSupportedException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidDataTypeException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidDataTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidFormatException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidFormatException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidPropertyException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidPropertyException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidPropertyMappingConfigurationException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidPropertyMappingConfigurationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidSource extends \TYPO3\CMS\Extbase\Property\Exception\InvalidSourceException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidSourceException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidSourceException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidTarget extends \TYPO3\CMS\Extbase\Property\Exception\InvalidTargetException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_InvalidTargetException extends \TYPO3\CMS\Extbase\Property\Exception\InvalidTargetException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_TargetNotFoundException extends \TYPO3\CMS\Extbase\Property\Exception\TargetNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_Exception_TypeConverterException extends \TYPO3\CMS\Extbase\Property\Exception\TypeConverterException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_PropertyMapper extends \TYPO3\CMS\Extbase\Property\PropertyMapper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_PropertyMappingConfiguration extends \TYPO3\CMS\Extbase\Property\PropertyMappingConfiguration {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_PropertyMappingConfigurationBuilder extends \TYPO3\CMS\Extbase\Property\PropertyMappingConfigurationBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Property_PropertyMappingConfigurationInterface extends \TYPO3\CMS\Extbase\Property\PropertyMappingConfigurationInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Property_TypeConverter_AbstractFileCollectionConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\AbstractFileCollectionConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Property_TypeConverter_AbstractFileFolderConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\AbstractFileFolderConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Property_TypeConverter_AbstractTypeConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\AbstractTypeConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_ArrayConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\ArrayConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_BooleanConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\BooleanConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_DateTimeConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_FileConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\FileConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_FileReferenceConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\FileReferenceConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_FloatConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\FloatConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_FolderBasedFileCollectionConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\FolderBasedFileCollectionConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_FolderConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\FolderConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_IntegerConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\IntegerConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_ObjectStorageConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\ObjectStorageConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_PersistentObjectConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\PersistentObjectConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_StaticFileCollectionConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\StaticFileCollectionConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Property_TypeConverter_StringConverter extends \TYPO3\CMS\Extbase\Property\TypeConverter\StringConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Property_TypeConverterInterface extends \TYPO3\CMS\Extbase\Property\TypeConverterInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_ClassReflection extends \TYPO3\CMS\Extbase\Reflection\ClassReflection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_ClassSchema extends \TYPO3\CMS\Extbase\Reflection\ClassSchema {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_DocCommentParser extends \TYPO3\CMS\Extbase\Reflection\DocCommentParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_Exception extends \TYPO3\CMS\Extbase\Reflection\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_Exception_InvalidPropertyType extends \TYPO3\CMS\Extbase\Reflection\Exception\InvalidPropertyTypeException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_Exception_PropertyNotAccessibleException extends \TYPO3\CMS\Extbase\Reflection\Exception\PropertyNotAccessibleException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_Exception_UnknownClass extends \TYPO3\CMS\Extbase\Reflection\Exception\UnknownClassException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_MethodReflection extends \TYPO3\CMS\Extbase\Reflection\MethodReflection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_ObjectAccess extends \TYPO3\CMS\Extbase\Reflection\ObjectAccess {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_ParameterReflection extends \TYPO3\CMS\Extbase\Reflection\ParameterReflection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_PropertyReflection extends \TYPO3\CMS\Extbase\Reflection\PropertyReflection {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Reflection_Service extends \TYPO3\CMS\Extbase\Reflection\ReflectionService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Scheduler_FieldProvider extends \TYPO3\CMS\Extbase\Scheduler\FieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Scheduler_Task extends \TYPO3\CMS\Extbase\Scheduler\Task {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Scheduler_TaskExecutor extends \TYPO3\CMS\Extbase\Scheduler\TaskExecutor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Cryptography_HashService extends \TYPO3\CMS\Extbase\Security\Cryptography\HashService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Exception extends \TYPO3\CMS\Extbase\Security\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Exception_InvalidArgumentForHashGeneration extends \TYPO3\CMS\Extbase\Security\Exception\InvalidArgumentForHashGenerationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Exception_InvalidArgumentForRequestHashGeneration extends \TYPO3\CMS\Extbase\Security\Exception\InvalidArgumentForRequestHashGenerationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Exception_InvalidHash extends \TYPO3\CMS\Extbase\Security\Exception\InvalidHashException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Security_Exception_SyntacticallyWrongRequestHash extends \TYPO3\CMS\Extbase\Security\Exception\SyntacticallyWrongRequestHashException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Service_CacheService extends \TYPO3\CMS\Extbase\Service\CacheService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Service_ExtensionService extends \TYPO3\CMS\Extbase\Service\ExtensionService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Service_FlexFormService extends \TYPO3\CMS\Extbase\Service\FlexFormService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Service_TypoScriptService extends \TYPO3\CMS\Extbase\Service\TypoScriptService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_SignalSlot_Dispatcher extends \TYPO3\CMS\Extbase\SignalSlot\Dispatcher {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_SignalSlot_Exception_InvalidSlotException extends \TYPO3\CMS\Extbase\SignalSlot\Exception\InvalidSlotException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Tests_Unit_BaseTestCase extends \TYPO3\CMS\Core\Tests\UnitTestCase {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_Arrays extends \TYPO3\CMS\Extbase\Utility\ArrayUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_Debugger extends \TYPO3\CMS\Extbase\Utility\DebuggerUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_ExtbaseRequirementsCheck extends \TYPO3\CMS\Extbase\Utility\ExtbaseRequirementsCheckUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_Extension extends \TYPO3\CMS\Extbase\Utility\ExtensionUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_FrontendSimulator extends \TYPO3\CMS\Extbase\Utility\FrontendSimulatorUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Utility_Localization extends \TYPO3\CMS\Extbase\Utility\LocalizationUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Error extends \TYPO3\CMS\Extbase\Validation\Error {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception extends \TYPO3\CMS\Extbase\Validation\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception_InvalidSubject extends \TYPO3\CMS\Extbase\Validation\Exception\InvalidSubjectException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception_InvalidValidationConfiguration extends \TYPO3\CMS\Extbase\Validation\Exception\InvalidValidationConfigurationException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception_InvalidValidationOptions extends \TYPO3\CMS\Extbase\Validation\Exception\InvalidValidationOptionsException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception_NoSuchValidator extends \TYPO3\CMS\Extbase\Validation\Exception\NoSuchValidatorException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Exception_NoValidatorFound extends \TYPO3\CMS\Extbase\Validation\Exception\NoValidatorFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Validation_Validator_AbstractCompositeValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractCompositeValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Extbase_Validation_Validator_AbstractValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_AlphanumericValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AlphanumericValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_ConjunctionValidator extends \TYPO3\CMS\Extbase\Validation\Validator\ConjunctionValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_DateTimeValidator extends \TYPO3\CMS\Extbase\Validation\Validator\DateTimeValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_DisjunctionValidator extends \TYPO3\CMS\Extbase\Validation\Validator\DisjunctionValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_EmailAddressValidator extends \TYPO3\CMS\Extbase\Validation\Validator\EmailAddressValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_FloatValidator extends \TYPO3\CMS\Extbase\Validation\Validator\FloatValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_GenericObjectValidator extends \TYPO3\CMS\Extbase\Validation\Validator\GenericObjectValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_IntegerValidator extends \TYPO3\CMS\Extbase\Validation\Validator\IntegerValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_NotEmptyValidator extends \TYPO3\CMS\Extbase\Validation\Validator\NotEmptyValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_NumberRangeValidator extends \TYPO3\CMS\Extbase\Validation\Validator\NumberRangeValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_NumberValidator extends \TYPO3\CMS\Extbase\Validation\Validator\NumberValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Validation_Validator_ObjectValidatorInterface extends \TYPO3\CMS\Extbase\Validation\Validator\ObjectValidatorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_RawValidator extends \TYPO3\CMS\Extbase\Validation\Validator\RawValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_RegularExpressionValidator extends \TYPO3\CMS\Extbase\Validation\Validator\RegularExpressionValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_StringLengthValidator extends \TYPO3\CMS\Extbase\Validation\Validator\StringLengthValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_StringValidator extends \TYPO3\CMS\Extbase\Validation\Validator\StringValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_Validator_TextValidator extends \TYPO3\CMS\Extbase\Validation\Validator\TextValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Extbase_Validation_Validator_ValidatorInterface extends \TYPO3\CMS\Extbase\Validation\Validator\ValidatorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Extbase_Validation_ValidatorResolver extends \TYPO3\CMS\Extbase\Validation\ValidatorResolver {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_em_Tasks_UpdateExtensionList extends \TYPO3\CMS\Extensionmanager\Task\UpdateExtensionListTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class fileList extends \TYPO3\CMS\Filelist\FileList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_feedit_editpanel extends \TYPO3\CMS\Feedit\FrontendEditPanel {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_felogin_pi1 extends \TYPO3\CMS\Felogin\Controller\FrontendLoginController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface fileList_editIconHook extends \TYPO3\CMS\Filelist\FileListEditIconHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class filelistFolderTree extends \TYPO3\CMS\Filelist\FileListFolderTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Compatibility_DocbookGeneratorService extends \TYPO3\CMS\Fluid\Compatibility\DocbookGeneratorService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Compatibility_TemplateParserBuilder extends \TYPO3\CMS\Fluid\Compatibility\TemplateParserBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_Compiler_AbstractCompiledTemplate extends \TYPO3\CMS\Fluid\Core\Compiler\AbstractCompiledTemplate {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Compiler_TemplateCompiler extends \TYPO3\CMS\Fluid\Core\Compiler\TemplateCompiler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Exception extends \TYPO3\CMS\Fluid\Core\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_Configuration extends \TYPO3\CMS\Fluid\Core\Parser\Configuration {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_Exception extends \TYPO3\CMS\Fluid\Core\Parser\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_Interceptor_Escape extends \TYPO3\CMS\Fluid\Core\Parser\Interceptor\Escape {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_Parser_InterceptorInterface extends \TYPO3\CMS\Fluid\Core\Parser\InterceptorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_Parser_ParsedTemplateInterface extends \TYPO3\CMS\Fluid\Core\Parser\ParsedTemplateInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_ParsingState extends \TYPO3\CMS\Fluid\Core\Parser\ParsingState {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_Parser_SyntaxTree_AbstractNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\AbstractNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_ArrayNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ArrayNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_BooleanNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\BooleanNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_Parser_SyntaxTree_NodeInterface extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\NodeInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_ObjectAccessorNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ObjectAccessorNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_RootNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\RootNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_TextNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\TextNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_SyntaxTree_ViewHelperNode extends \TYPO3\CMS\Fluid\Core\Parser\SyntaxTree\ViewHelperNode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Parser_TemplateParser extends \TYPO3\CMS\Fluid\Core\Parser\TemplateParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Rendering_RenderingContext extends \TYPO3\CMS\Fluid\Core\Rendering\RenderingContext {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_Rendering_RenderingContextInterface extends \TYPO3\CMS\Fluid\Core\Rendering\RenderingContextInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_ViewHelper_AbstractConditionViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractConditionViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_ViewHelper_AbstractTagBasedViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractTagBasedViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_ViewHelper_AbstractViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_ArgumentDefinition extends \TYPO3\CMS\Fluid\Core\ViewHelper\ArgumentDefinition {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_Arguments extends \TYPO3\CMS\Fluid\Core\ViewHelper\Arguments {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_Exception extends \TYPO3\CMS\Fluid\Core\ViewHelper\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_Exception_InvalidVariableException extends \TYPO3\CMS\Fluid\Core\ViewHelper\Exception\InvalidVariableException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_Widget_AbstractWidgetController extends \TYPO3\CMS\Fluid\Core\Widget\AbstractWidgetController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_Core_Widget_AbstractWidgetViewHelper extends \TYPO3\CMS\Fluid\Core\Widget\AbstractWidgetViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_AjaxWidgetContextHolder extends \TYPO3\CMS\Fluid\Core\Widget\AjaxWidgetContextHolder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Bootstrap extends \TYPO3\CMS\Fluid\Core\Widget\Bootstrap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Exception extends \TYPO3\CMS\Fluid\Core\Widget\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Exception_MissingControllerException extends \TYPO3\CMS\Fluid\Core\Widget\Exception\MissingControllerException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Exception_RenderingContextNotFoundException extends \TYPO3\CMS\Fluid\Core\Widget\Exception\RenderingContextNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Exception_WidgetContextNotFoundException extends \TYPO3\CMS\Fluid\Core\Widget\Exception\WidgetContextNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_Exception_WidgetRequestNotFoundException extends \TYPO3\CMS\Fluid\Core\Widget\Exception\WidgetRequestNotFoundException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_WidgetContext extends \TYPO3\CMS\Fluid\Core\Widget\WidgetContext {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_WidgetRequest extends \TYPO3\CMS\Fluid\Core\Widget\WidgetRequest {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_WidgetRequestBuilder extends \TYPO3\CMS\Fluid\Core\Widget\WidgetRequestBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_Widget_WidgetRequestHandler extends \TYPO3\CMS\Fluid\Core\Widget\WidgetRequestHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_Exception_RenderingContextNotAccessibleException extends \TYPO3\CMS\Fluid\Core\ViewHelper\Exception\RenderingContextNotAccessibleException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_ViewHelper_Facets_ChildNodeAccessInterface extends \TYPO3\CMS\Fluid\Core\ViewHelper\Facets\ChildNodeAccessInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_ViewHelper_Facets_CompilableInterface extends \TYPO3\CMS\Fluid\Core\ViewHelper\Facets\CompilableInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_ViewHelper_Facets_PostParseInterface extends \TYPO3\CMS\Fluid\Core\ViewHelper\Facets\PostParseInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_TagBuilder extends \TYPO3\CMS\Fluid\Core\ViewHelper\TagBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_TemplateVariableContainer extends \TYPO3\CMS\Fluid\Core\ViewHelper\TemplateVariableContainer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface Tx_Fluid_Core_ViewHelper_ViewHelperInterface extends \TYPO3\CMS\Fluid\Core\ViewHelper\ViewHelperInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Core_ViewHelper_ViewHelperVariableContainer extends \TYPO3\CMS\Fluid\Core\ViewHelper\ViewHelperVariableContainer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Exception extends \TYPO3\CMS\Fluid\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Fluid extends \TYPO3\CMS\Fluid\Fluid {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_Service_DocbookGenerator extends \TYPO3\CMS\Fluid\Service\DocbookGenerator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_View_AbstractTemplateView extends \TYPO3\CMS\Fluid\View\AbstractTemplateView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_View_Exception extends \TYPO3\CMS\Fluid\View\Exception {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_View_Exception_InvalidSectionException extends \TYPO3\CMS\Fluid\View\Exception\InvalidSectionException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_View_Exception_InvalidTemplateResourceException extends \TYPO3\CMS\Fluid\View\Exception\InvalidTemplateResourceException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_View_StandaloneView extends \TYPO3\CMS\Fluid\View\StandaloneView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_View_TemplateView extends \TYPO3\CMS\Fluid\View\TemplateView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_AliasViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\AliasViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_BaseViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\BaseViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_ViewHelpers_Be_AbstractBackendViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\AbstractBackendViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Buttons_CshViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Buttons\CshViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Buttons_IconViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Buttons\IconViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Buttons_ShortcutViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Buttons\ShortcutViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_ContainerViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\ContainerViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Menus_ActionMenuItemViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Menus\ActionMenuItemViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Menus_ActionMenuViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Menus\ActionMenuViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_PageInfoViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\PageInfoViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_PagePathViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\PagePathViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Security_IfAuthenticatedViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Security\IfAuthenticatedViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_Security_IfHasRoleViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\Security\IfHasRoleViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Be_TableListViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Be\TableListViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_CObjectViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\CObjectViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_CommentViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\CommentViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_CountViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\CountViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_CycleViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\CycleViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_DebugViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\DebugViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_ElseViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\ElseViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_FlashMessagesViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\FlashMessagesViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_ViewHelpers_Form_AbstractFormFieldViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\AbstractFormFieldViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_ViewHelpers_Form_AbstractFormViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\AbstractFormViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_CheckboxViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\CheckboxViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_HiddenViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\HiddenViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_PasswordViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\PasswordViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_RadioViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\RadioViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_SelectViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_SubmitViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_TextareaViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextareaViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_TextfieldViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_UploadViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\UploadViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Form_ValidationResultsViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\ValidationResultsViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Fluid_ViewHelpers_Format_AbstractEncodingViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\AbstractEncodingViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_CdataViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\CdataViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_CropViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\CropViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_CurrencyViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\CurrencyViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_DateViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_HtmlentitiesDecodeViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlentitiesDecodeViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_HtmlentitiesViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlentitiesViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_HtmlspecialcharsViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlspecialcharsViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_HtmlViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\HtmlViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_Nl2brViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\Nl2brViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_NumberViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\NumberViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_PaddingViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\PaddingViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_PrintfViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\PrintfViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_RawViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\RawViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_StripTagsViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\StripTagsViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Format_UrlencodeViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Format\UrlencodeViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_FormViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_ForViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\ForViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_GroupedForViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\GroupedForViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_IfViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\IfViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_ImageViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\ImageViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_LayoutViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\LayoutViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Link_ActionViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Link\ActionViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Link_EmailViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Link\EmailViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Link_ExternalViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Link\ExternalViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Link_PageViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Link\PageViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_RenderChildrenViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\RenderChildrenViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_RenderViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\RenderViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_SectionViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\SectionViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Security_IfAuthenticatedViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Security\IfAuthenticatedViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Security_IfHasRoleViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Security\IfHasRoleViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_ThenViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\ThenViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_TranslateViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\TranslateViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_ActionViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\ActionViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_EmailViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\EmailViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_ExternalViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\ExternalViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_ImageViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\ImageViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_PageViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\PageViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Uri_ResourceViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Uri\ResourceViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_AutocompleteViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\AutocompleteViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_Controller_AutocompleteController extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\Controller\AutocompleteController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_Controller_PaginateController extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\Controller\PaginateController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_LinkViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\LinkViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_PaginateViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\PaginateViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Fluid_ViewHelpers_Widget_UriViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Widget\UriViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Controller_Form extends \TYPO3\CMS\Form\Controller\FormController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Controller_Wizard extends \TYPO3\CMS\Form\Controller\WizardController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Factory_JsonToTyposcript extends \TYPO3\CMS\Form\Domain\Factory\JsonToTypoScript {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Factory_Typoscript extends \TYPO3\CMS\Form\Domain\Factory\TypoScriptFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_Domain_Model_Additional_Abstract extends \TYPO3\CMS\Form\Domain\Model\Additional\AbstractAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Additional_Additional extends \TYPO3\CMS\Form\Domain\Model\Additional\AdditionalAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Additional_Error extends \TYPO3\CMS\Form\Domain\Model\Additional\ErrorAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Additional_Label extends \TYPO3\CMS\Form\Domain\Model\Additional\LabelAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Additional_Legend extends \TYPO3\CMS\Form\Domain\Model\Additional\LegendAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Additional_Mandatory extends \TYPO3\CMS\Form\Domain\Model\Additional\MandatoryAdditionalElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_Domain_Model_Attributes_Abstract extends \TYPO3\CMS\Form\Domain\Model\Attribute\AbstractAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Accept extends \TYPO3\CMS\Form\Domain\Model\Attribute\AcceptAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Acceptcharset extends \TYPO3\CMS\Form\Domain\Model\Attribute\AcceptCharsetAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Accesskey extends \TYPO3\CMS\Form\Domain\Model\Attribute\AccesskeyAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Action extends \TYPO3\CMS\Form\Domain\Model\Attribute\ActionAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Alt extends \TYPO3\CMS\Form\Domain\Model\Attribute\AltAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Attributes extends \TYPO3\CMS\Form\Domain\Model\Attribute\AttributesAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Checked extends \TYPO3\CMS\Form\Domain\Model\Attribute\CheckedAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Class extends \TYPO3\CMS\Form\Domain\Model\Attribute\ClassAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Cols extends \TYPO3\CMS\Form\Domain\Model\Attribute\ColsAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Dir extends \TYPO3\CMS\Form\Domain\Model\Attribute\DirAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Disabled extends \TYPO3\CMS\Form\Domain\Model\Attribute\DisabledAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Enctype extends \TYPO3\CMS\Form\Domain\Model\Attribute\EnctypeAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Id extends \TYPO3\CMS\Form\Domain\Model\Attribute\IdAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Label extends \TYPO3\CMS\Form\Domain\Model\Attribute\LabelAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Lang extends \TYPO3\CMS\Form\Domain\Model\Attribute\LangAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Maxlength extends \TYPO3\CMS\Form\Domain\Model\Attribute\MaxlengthAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Method extends \TYPO3\CMS\Form\Domain\Model\Attribute\MethodAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Multiple extends \TYPO3\CMS\Form\Domain\Model\Attribute\MultipleAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Name extends \TYPO3\CMS\Form\Domain\Model\Attribute\NameAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Readonly extends \TYPO3\CMS\Form\Domain\Model\Attribute\ReadonlyAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Rows extends \TYPO3\CMS\Form\Domain\Model\Attribute\RowsAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Selected extends \TYPO3\CMS\Form\Domain\Model\Attribute\SelectedAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Size extends \TYPO3\CMS\Form\Domain\Model\Attribute\SizeAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Src extends \TYPO3\CMS\Form\Domain\Model\Attribute\SrcAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Style extends \TYPO3\CMS\Form\Domain\Model\Attribute\StyleAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Tabindex extends \TYPO3\CMS\Form\Domain\Model\Attribute\TabindexAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Title extends \TYPO3\CMS\Form\Domain\Model\Attribute\TitleAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Type extends \TYPO3\CMS\Form\Domain\Model\Attribute\TypeAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Attributes_Value extends \TYPO3\CMS\Form\Domain\Model\Attribute\ValueAttribute {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Content extends \TYPO3\CMS\Form\Domain\Model\Content {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_Domain_Model_Element_Abstract extends \TYPO3\CMS\Form\Domain\Model\Element\AbstractElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_Domain_Model_Element_AbstractPlain extends \TYPO3\CMS\Form\Domain\Model\Element\AbstractPlainElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Button extends \TYPO3\CMS\Form\Domain\Model\Element\ButtonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Checkbox extends \TYPO3\CMS\Form\Domain\Model\Element\CheckboxElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Checkboxgroup extends \TYPO3\CMS\Form\Domain\Model\Element\CheckboxGroupElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Container extends \TYPO3\CMS\Form\Domain\Model\Element\ContainerElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Content extends \TYPO3\CMS\Form\Domain\Model\Element\ContentElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Fieldset extends \TYPO3\CMS\Form\Domain\Model\Element\FieldsetElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Fileupload extends \TYPO3\CMS\Form\Domain\Model\Element\FileuploadElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Header extends \TYPO3\CMS\Form\Domain\Model\Element\HeaderElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Hidden extends \TYPO3\CMS\Form\Domain\Model\Element\HiddenElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Imagebutton extends \TYPO3\CMS\Form\Domain\Model\Element\ImagebuttonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Optgroup extends \TYPO3\CMS\Form\Domain\Model\Element\OptgroupElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Option extends \TYPO3\CMS\Form\Domain\Model\Element\OptionElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Password extends \TYPO3\CMS\Form\Domain\Model\Element\PasswordElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Radio extends \TYPO3\CMS\Form\Domain\Model\Element\RadioElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Radiogroup extends \TYPO3\CMS\Form\Domain\Model\Element\RadioGroupElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Reset extends \TYPO3\CMS\Form\Domain\Model\Element\ResetElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Select extends \TYPO3\CMS\Form\Domain\Model\Element\SelectElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Submit extends \TYPO3\CMS\Form\Domain\Model\Element\SubmitElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Textarea extends \TYPO3\CMS\Form\Domain\Model\Element\TextareaElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Textblock extends \TYPO3\CMS\Form\Domain\Model\Element\TextblockElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Element_Textline extends \TYPO3\CMS\Form\Domain\Model\Element\TextlineElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_Form extends \TYPO3\CMS\Form\Domain\Model\Form {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_Domain_Model_JSON_Element extends \TYPO3\CMS\Form\Domain\Model\Json\AbstractJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Button extends \TYPO3\CMS\Form\Domain\Model\Json\ButtonJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Checkboxgroup extends \TYPO3\CMS\Form\Domain\Model\Json\CheckboxGroupJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Checkbox extends \TYPO3\CMS\Form\Domain\Model\Json\CheckboxJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Container extends \TYPO3\CMS\Form\Domain\Model\Json\ContainerJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Fieldset extends \TYPO3\CMS\Form\Domain\Model\Json\FieldsetJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Fileupload extends \TYPO3\CMS\Form\Domain\Model\Json\FileuploadJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Form extends \TYPO3\CMS\Form\Domain\Model\Json\FormJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Header extends \TYPO3\CMS\Form\Domain\Model\Json\HeaderJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Hidden extends \TYPO3\CMS\Form\Domain\Model\Json\HiddenJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Name extends \TYPO3\CMS\Form\Domain\Model\Json\NameJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Password extends \TYPO3\CMS\Form\Domain\Model\Json\PasswordJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Radiogroup extends \TYPO3\CMS\Form\Domain\Model\Json\RadioGroupJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Radio extends \TYPO3\CMS\Form\Domain\Model\Json\RadioJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Reset extends \TYPO3\CMS\Form\Domain\Model\Json\ResetJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Select extends \TYPO3\CMS\Form\Domain\Model\Json\SelectJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Submit extends \TYPO3\CMS\Form\Domain\Model\Json\SubmitJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Textarea extends \TYPO3\CMS\Form\Domain\Model\Json\TextareaJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Textblock extends \TYPO3\CMS\Form\Domain\Model\Json\TextblockJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Model_JSON_Textline extends \TYPO3\CMS\Form\Domain\Model\Json\TextlineJsonElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Repository_Content extends \TYPO3\CMS\Form\Domain\Repository\ContentRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Domain_Factory_TyposcriptToJson extends \TYPO3\CMS\Form\Utility\TypoScriptToJsonConverter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Elementcounter extends \TYPO3\CMS\Form\ElementCounter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Alphabetic extends \TYPO3\CMS\Form\Filter\AlphabeticFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Alphanumeric extends \TYPO3\CMS\Form\Filter\AlphanumericFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Currency extends \TYPO3\CMS\Form\Filter\CurrencyFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Digit extends \TYPO3\CMS\Form\Filter\DigitFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_form_System_Filter_Interface extends \TYPO3\CMS\Form\Filter\FilterInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Integer extends \TYPO3\CMS\Form\Filter\IntegerFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Lowercase extends \TYPO3\CMS\Form\Filter\LowerCaseFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Regexp extends \TYPO3\CMS\Form\Filter\RegExpFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Removexss extends \TYPO3\CMS\Form\Filter\RemoveXssFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Stripnewlines extends \TYPO3\CMS\Form\Filter\StripNewLinesFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Titlecase extends \TYPO3\CMS\Form\Filter\TitleCaseFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Trim extends \TYPO3\CMS\Form\Filter\TrimFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter_Uppercase extends \TYPO3\CMS\Form\Filter\UpperCaseFilter {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Filter extends \TYPO3\CMS\Form\Utility\FilterUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Layout extends \TYPO3\CMS\Form\Layout {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Localization extends \TYPO3\CMS\Form\Localization {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Postprocessor_Mail extends \TYPO3\CMS\Form\PostProcess\MailPostProcessor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Postprocessor extends \TYPO3\CMS\Form\PostProcess\PostProcessor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_form_System_Postprocessor_Interface extends \TYPO3\CMS\Form\PostProcess\PostProcessorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Request extends \TYPO3\CMS\Form\Request {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_Common extends \TYPO3\CMS\Form\Utility\FormUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate extends \TYPO3\CMS\Form\Utility\ValidatorUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_System_Validate_Abstract extends \TYPO3\CMS\Form\Validation\AbstractValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Alphabetic extends \TYPO3\CMS\Form\Validation\AlphabeticValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Alphanumeric extends \TYPO3\CMS\Form\Validation\AlphanumericValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Between extends \TYPO3\CMS\Form\Validation\BetweenValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Date extends \TYPO3\CMS\Form\Validation\DateValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Digit extends \TYPO3\CMS\Form\Validation\DigitValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Email extends \TYPO3\CMS\Form\Validation\EmailValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Equals extends \TYPO3\CMS\Form\Validation\EqualsValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Fileallowedtypes extends \TYPO3\CMS\Form\Validation\FileAllowedTypesValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Filemaximumsize extends \TYPO3\CMS\Form\Validation\FileMaximumSizeValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Fileminimumsize extends \TYPO3\CMS\Form\Validation\FileMinimumSizeValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Float extends \TYPO3\CMS\Form\Validation\FloatValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Greaterthan extends \TYPO3\CMS\Form\Validation\GreaterThanValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Inarray extends \TYPO3\CMS\Form\Validation\InArrayValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Integer extends \TYPO3\CMS\Form\Validation\IntegerValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_form_System_Validate_Interface extends \TYPO3\CMS\Form\Validation\ValidatorInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Ip extends \TYPO3\CMS\Form\Validation\IpValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Length extends \TYPO3\CMS\Form\Validation\LengthValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Lessthan extends \TYPO3\CMS\Form\Validation\LessthanValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Regexp extends \TYPO3\CMS\Form\Validation\RegExpValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Required extends \TYPO3\CMS\Form\Validation\RequiredValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_System_Validate_Uri extends \TYPO3\CMS\Form\Validation\UriValidator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Additional extends \TYPO3\CMS\Form\View\Confirmation\Additional\AdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Additional_Label extends \TYPO3\CMS\Form\View\Confirmation\Additional\LabelAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Additional_Legend extends \TYPO3\CMS\Form\View\Confirmation\Additional\LegendAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation extends \TYPO3\CMS\Form\View\Confirmation\ConfirmationView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_View_Confirmation_Element_Abstract extends \TYPO3\CMS\Form\View\Confirmation\Element\AbstractElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Checkbox extends \TYPO3\CMS\Form\View\Confirmation\Element\CheckboxElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Checkboxgroup extends \TYPO3\CMS\Form\View\Confirmation\Element\CheckboxGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Container extends \TYPO3\CMS\Form\View\Confirmation\Element\ContainerElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Fieldset extends \TYPO3\CMS\Form\View\Confirmation\Element\FieldsetElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Fileupload extends \TYPO3\CMS\Form\View\Confirmation\Element\FileuploadElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Optgroup extends \TYPO3\CMS\Form\View\Confirmation\Element\OptgroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Option extends \TYPO3\CMS\Form\View\Confirmation\Element\OptionElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Radio extends \TYPO3\CMS\Form\View\Confirmation\Element\RadioElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Radiogroup extends \TYPO3\CMS\Form\View\Confirmation\Element\RadioGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Select extends \TYPO3\CMS\Form\View\Confirmation\Element\SelectElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Textarea extends \TYPO3\CMS\Form\View\Confirmation\Element\TextareaElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Confirmation_Element_Textline extends \TYPO3\CMS\Form\View\Confirmation\Element\TextlineElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Additional extends \TYPO3\CMS\Form\View\Form\Additional\AdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Additional_Error extends \TYPO3\CMS\Form\View\Form\Additional\ErrorAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Additional_Label extends \TYPO3\CMS\Form\View\Form\Additional\LabelAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Additional_Legend extends \TYPO3\CMS\Form\View\Form\Additional\LegendAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Additional_Mandatory extends \TYPO3\CMS\Form\View\Form\Additional\MandatoryAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_View_Form_Element_Abstract extends \TYPO3\CMS\Form\View\Form\Element\AbstractElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Button extends \TYPO3\CMS\Form\View\Form\Element\ButtonElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Checkbox extends \TYPO3\CMS\Form\View\Form\Element\CheckboxElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Checkboxgroup extends \TYPO3\CMS\Form\View\Form\Element\CheckboxGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Container extends \TYPO3\CMS\Form\View\Form\Element\ContainerElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Content extends \TYPO3\CMS\Form\View\Form\Element\ContentElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Fieldset extends \TYPO3\CMS\Form\View\Form\Element\FieldsetElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Fileupload extends \TYPO3\CMS\Form\View\Form\Element\FileuploadElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Header extends \TYPO3\CMS\Form\View\Form\Element\HeaderElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Hidden extends \TYPO3\CMS\Form\View\Form\Element\HiddenElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Imagebutton extends \TYPO3\CMS\Form\View\Form\Element\ImagebuttonElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Optgroup extends \TYPO3\CMS\Form\View\Form\Element\OptgroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Option extends \TYPO3\CMS\Form\View\Form\Element\OptionElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Password extends \TYPO3\CMS\Form\View\Form\Element\PasswordElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Radio extends \TYPO3\CMS\Form\View\Form\Element\RadioElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Radiogroup extends \TYPO3\CMS\Form\View\Form\Element\RadioGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Reset extends \TYPO3\CMS\Form\View\Form\Element\ResetElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Select extends \TYPO3\CMS\Form\View\Form\Element\SelectElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Submit extends \TYPO3\CMS\Form\View\Form\Element\SubmitElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Textarea extends \TYPO3\CMS\Form\View\Form\Element\TextareaElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Textblock extends \TYPO3\CMS\Form\View\Form\Element\TextblockElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form_Element_Textline extends \TYPO3\CMS\Form\View\Form\Element\TextlineElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Form extends \TYPO3\CMS\Form\View\Form\FormView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Additional extends \TYPO3\CMS\Form\View\Mail\Html\Additional\AdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Additional_Label extends \TYPO3\CMS\Form\View\Mail\Html\Additional\LabelAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Additional_Legend extends \TYPO3\CMS\Form\View\Mail\Html\Additional\LegendAdditionalElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_View_Mail_Html_Element_Abstract extends \TYPO3\CMS\Form\View\Mail\Html\Element\AbstractElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Checkbox extends \TYPO3\CMS\Form\View\Mail\Html\Element\CheckboxElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Checkboxgroup extends \TYPO3\CMS\Form\View\Mail\Html\Element\CheckboxGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Container extends \TYPO3\CMS\Form\View\Mail\Html\Element\ContainerElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Fieldset extends \TYPO3\CMS\Form\View\Mail\Html\Element\FieldsetElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Fileupload extends \TYPO3\CMS\Form\View\Mail\Html\Element\FileuploadElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Hidden extends \TYPO3\CMS\Form\View\Mail\Html\Element\HiddenElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Optgroup extends \TYPO3\CMS\Form\View\Mail\Html\Element\OptgroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Option extends \TYPO3\CMS\Form\View\Mail\Html\Element\OptionElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Radio extends \TYPO3\CMS\Form\View\Mail\Html\Element\RadioElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Radiogroup extends \TYPO3\CMS\Form\View\Mail\Html\Element\RadioGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Select extends \TYPO3\CMS\Form\View\Mail\Html\Element\SelectElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Textarea extends \TYPO3\CMS\Form\View\Mail\Html\Element\TextareaElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html_Element_Textline extends \TYPO3\CMS\Form\View\Mail\Html\Element\TextlineElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Html extends \TYPO3\CMS\Form\View\Mail\Html\HtmlView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail extends \TYPO3\CMS\Form\View\Mail\MailView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_View_Mail_Plain_Element_Abstract extends \TYPO3\CMS\Form\View\Mail\Plain\Element\AbstractElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Checkbox extends \TYPO3\CMS\Form\View\Mail\Plain\Element\CheckboxElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Checkboxgroup extends \TYPO3\CMS\Form\View\Mail\Plain\Element\CheckboxGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Container extends \TYPO3\CMS\Form\View\Mail\Plain\Element\ContainerElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Fieldset extends \TYPO3\CMS\Form\View\Mail\Plain\Element\FieldsetElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Fileupload extends \TYPO3\CMS\Form\View\Mail\Plain\Element\FileuploadElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Hidden extends \TYPO3\CMS\Form\View\Mail\Plain\Element\HiddenElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Optgroup extends \TYPO3\CMS\Form\View\Mail\Plain\Element\OptgroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Option extends \TYPO3\CMS\Form\View\Mail\Plain\Element\OptionElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Radio extends \TYPO3\CMS\Form\View\Mail\Plain\Element\RadioElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Radiogroup extends \TYPO3\CMS\Form\View\Mail\Plain\Element\RadioGroupElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Select extends \TYPO3\CMS\Form\View\Mail\Plain\Element\SelectElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Textarea extends \TYPO3\CMS\Form\View\Mail\Plain\Element\TextareaElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain_Element_Textline extends \TYPO3\CMS\Form\View\Mail\Plain\Element\TextlineElementView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Mail_Plain extends \TYPO3\CMS\Form\View\Mail\Plain\PlainView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_form_View_Wizard_Abstract extends \TYPO3\CMS\Form\View\Wizard\AbstractWizardView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Wizard_Load extends \TYPO3\CMS\Form\View\Wizard\LoadWizardView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Wizard_Save extends \TYPO3\CMS\Form\View\Wizard\SaveWizardView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_form_View_Wizard_Wizard extends \TYPO3\CMS\Form\View\Wizard\WizardView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_feUserAuth extends \TYPO3\CMS\Frontend\Authentication\FrontendUserAuthentication {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_matchCondition_frontend extends \TYPO3\CMS\Frontend\Configuration\TypoScript\ConditionMatching\ConditionMatcher {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_formmail extends \TYPO3\CMS\Compatibility6\Controller\FormDataSubmissionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tslib_content_Abstract extends \TYPO3\CMS\Frontend\ContentObject\AbstractContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Case extends \TYPO3\CMS\Frontend\ContentObject\CaseContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ClearGif extends \TYPO3\CMS\Compatibility6\ContentObject\ClearGifContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Columns extends \TYPO3\CMS\Compatibility6\ContentObject\ColumnsContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Content extends \TYPO3\CMS\Frontend\ContentObject\ContentContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ContentObjectArray extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectArrayContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ContentObjectArrayInternal extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectArrayInternalContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_getDataHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectGetDataHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_cObj_getImgResourceHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectGetImageResourceHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_getPublicUrlForFileHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectGetPublicUrlForFileHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_cObjGetSingleHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectGetSingleHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_PostInitHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectPostInitHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_cObj extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_stdWrapHook extends \TYPO3\CMS\Frontend\ContentObject\ContentObjectStdWrapHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ContentTable extends \TYPO3\CMS\Compatibility6\ContentObject\ContentTableContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_EditPanel extends \TYPO3\CMS\Frontend\ContentObject\EditPanelContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_File extends \TYPO3\CMS\Frontend\ContentObject\FileContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_content_fileLinkHook extends \TYPO3\CMS\Frontend\ContentObject\FileLinkHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Files extends \TYPO3\CMS\Frontend\ContentObject\FilesContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_FlowPlayer extends \TYPO3\CMS\Mediace\ContentObject\FlowPlayerContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_FluidTemplate extends \TYPO3\CMS\Frontend\ContentObject\FluidTemplateContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Form extends \TYPO3\CMS\Compatibility6\ContentObject\FormContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_HierarchicalMenu extends \TYPO3\CMS\Frontend\ContentObject\HierarchicalMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_HorizontalRuler extends \TYPO3\CMS\Compatibility6\ContentObject\HorizontalRulerContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Image extends \TYPO3\CMS\Frontend\ContentObject\ImageContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ImageResource extends \TYPO3\CMS\Frontend\ContentObject\ImageResourceContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ImageText extends \TYPO3\CMS\Compatibility6\ContentObject\ImageTextContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_LoadRegister extends \TYPO3\CMS\Frontend\ContentObject\LoadRegisterContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Media extends \TYPO3\CMS\Mediace\ContentObject\MediaContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Multimedia extends \TYPO3\CMS\Mediace\ContentObject\MultimediaContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_OffsetTable extends \TYPO3\CMS\Compatibility6\ContentObject\OffsetTableContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_QuicktimeObject extends \TYPO3\CMS\Mediace\ContentObject\QuicktimeObjectContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Records extends \TYPO3\CMS\Frontend\ContentObject\RecordsContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_RestoreRegister extends \TYPO3\CMS\Frontend\ContentObject\RestoreRegisterContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ScalableVectorGraphics extends \TYPO3\CMS\Frontend\ContentObject\ScalableVectorGraphicsContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_SearchResult extends \TYPO3\CMS\Compatibility6\ContentObject\SearchResultContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_ShockwaveFlashObject extends \TYPO3\CMS\Mediace\ContentObject\ShockwaveFlashObjectContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Template extends \TYPO3\CMS\Frontend\ContentObject\TemplateContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_Text extends \TYPO3\CMS\Frontend\ContentObject\TextContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_User extends \TYPO3\CMS\Frontend\ContentObject\UserContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_content_UserInternal extends \TYPO3\CMS\Frontend\ContentObject\UserInternalContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tslib_menu extends \TYPO3\CMS\Frontend\ContentObject\Menu\AbstractMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_menu_filterMenuPagesHook extends \TYPO3\CMS\Frontend\ContentObject\Menu\AbstractMenuFilterPagesHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_gmenu extends \TYPO3\CMS\Frontend\ContentObject\Menu\GraphicalMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_imgmenu extends \TYPO3\CMS\Frontend\ContentObject\Menu\ImageMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_tableOffset extends \TYPO3\CMS\Compatibility6\ContentObject\OffsetTableContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_search extends \TYPO3\CMS\Compatibility6\ContentObject\SearchResultContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_controlTable extends \TYPO3\CMS\Compatibility6\ContentObject\TableRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_ExtDirectEid extends \TYPO3\CMS\Frontend\Controller\ExtDirectEidController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_webinfo_page extends \TYPO3\CMS\Frontend\Controller\PageInformationController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_tslib_showpic extends \TYPO3\CMS\Frontend\Controller\ShowImageController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_webinfo_lang extends \TYPO3\CMS\Frontend\Controller\TranslationStatusController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_jsmenu extends \TYPO3\CMS\Frontend\ContentObject\Menu\JavaScriptMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_tmenu extends \TYPO3\CMS\Frontend\ContentObject\Menu\TextMenuContentObject {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_fe extends \TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_fehooks extends \TYPO3\CMS\Frontend\Hooks\FrontendHooks {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_mediaItems extends \TYPO3\CMS\Frontend\Hooks\MediaItemHooks {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_cms_treelistCacheUpdate extends \TYPO3\CMS\Frontend\Hooks\TreelistCacheUpdateHooks {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_gifBuilder extends \TYPO3\CMS\Frontend\Imaging\GifBuilder {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_mediaWizardCoreProvider extends \TYPO3\CMS\Mediace\MediaWizard\MediaWizardProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_mediaWizardProvider extends \TYPO3\CMS\Mediace\MediaWizard\MediaWizardProviderInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_mediaWizardManager extends \TYPO3\CMS\Mediace\MediaWizard\MediaWizardProviderManager {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_cacheHash extends \TYPO3\CMS\Frontend\Page\CacheHashCalculator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_frameset extends \TYPO3\CMS\Frontend\Page\FramesetRenderer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class TSpagegen extends \TYPO3\CMS\Frontend\Page\PageGenerator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_pageSelect extends \TYPO3\CMS\Frontend\Page\PageRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_pageSelect_getPageHook extends \TYPO3\CMS\Frontend\Page\PageRepositoryGetPageHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_pageSelect_getPageOverlayHook extends \TYPO3\CMS\Frontend\Page\PageRepositoryGetPageOverlayHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface t3lib_pageSelect_getRecordOverlayHook extends \TYPO3\CMS\Frontend\Page\PageRepositoryGetRecordOverlayHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tslib_pibase extends \TYPO3\CMS\Frontend\Plugin\AbstractPlugin {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_fecompression extends \TYPO3\CMS\Frontend\Utility\CompressionUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_eidtools extends \TYPO3\CMS\Frontend\Utility\EidUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tslib_AdminPanel extends \TYPO3\CMS\Frontend\View\AdminPanelView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tslib_adminPanelHook extends \TYPO3\CMS\Frontend\View\AdminPanelViewHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_web_func_index extends \TYPO3\CMS\Func\Controller\PageFunctionsController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_funcwizards_webfunc extends \TYPO3\CMS\Compatibility6\Controller\WebFunctionWizardsBaseController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_impexp_clickmenu extends \TYPO3\CMS\Impexp\Clickmenu {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_tools_log_index extends \TYPO3\CMS\Impexp\Controller\ImportExportController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_impexp extends \TYPO3\CMS\Impexp\ImportExport {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_impexp_localPageTree extends \TYPO3\CMS\Impexp\View\ExportPageTreeView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_impexp_task extends \TYPO3\CMS\Impexp\Task\ImportExportTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_files extends \TYPO3\CMS\IndexedSearch\Hook\CrawlerFilesHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_crawler extends \TYPO3\CMS\IndexedSearch\Hook\CrawlerHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_mysql extends \TYPO3\CMS\IndexedSearchMysql\Hook\MysqlFulltextIndexHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_tslib_fe_hook extends \TYPO3\CMS\IndexedSearch\Hook\TypoScriptFrontendHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_indexer extends \TYPO3\CMS\IndexedSearch\Indexer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_lexer extends \TYPO3\CMS\IndexedSearch\Lexer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexedsearch_util extends \TYPO3\CMS\IndexedSearch\Utility\IndexedSearchUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_indexed_search_extparse extends \TYPO3\CMS\IndexedSearch\FileContentParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class user_DoubleMetaPhone extends \TYPO3\CMS\IndexedSearch\Utility\DoubleMetaPhoneUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_IndexedSearch_Domain_Repository_IndexSearchRepository extends \TYPO3\CMS\IndexedSearch\Domain\Repository\IndexSearchRepository {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_IndexedSearch_ViewHelpers_PageBrowsingResultsViewHelper extends \TYPO3\CMS\IndexedSearch\ViewHelpers\PageBrowsingResultsViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_web_info_index extends \TYPO3\CMS\Info\Controller\InfoModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_infopagetsconfig_webinfo extends \TYPO3\CMS\InfoPagetsconfig\Controller\InfoPageTyposcriptConfigController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Install_Service_BasicService extends \TYPO3\CMS\Install\Service\EnableFileService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_install_report_InstallStatus extends \TYPO3\CMS\Install\Report\InstallStatusReport {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_install_session extends \TYPO3\CMS\Install\Service\SessionService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_install_Sql extends \TYPO3\CMS\Install\Service\SqlSchemaMigrationService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Install_Updates_Base extends \TYPO3\CMS\Install\Updates\AbstractUpdate {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class language extends \TYPO3\CMS\Lang\LanguageService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_Processor extends \TYPO3\CMS\Linkvalidator\LinkAnalyzer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_linkvalidator_linktype_Abstract extends \TYPO3\CMS\Linkvalidator\Linktype\AbstractLinktype {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_linktype_External extends \TYPO3\CMS\Linkvalidator\Linktype\ExternalLinktype {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_linktype_File extends \TYPO3\CMS\Linkvalidator\Linktype\FileLinktype {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_linktype_Internal extends \TYPO3\CMS\Linkvalidator\Linktype\InternalLinktype {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_linktype_LinkHandler extends \TYPO3\CMS\Linkvalidator\Linktype\LinkHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_linkvalidator_linktype_Interface extends \TYPO3\CMS\Linkvalidator\Linktype\LinktypeInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_ModFuncReport extends \TYPO3\CMS\Linkvalidator\Report\LinkValidatorReport {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_tasks_Validator extends \TYPO3\CMS\Linkvalidator\Task\ValidatorTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_linkvalidator_tasks_ValidatorAdditionalFieldProvider extends \TYPO3\CMS\Linkvalidator\Task\ValidatorTaskAdditionalFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_admin_core extends \TYPO3\CMS\Lowlevel\AdminCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_cleaner_core extends \TYPO3\CMS\Lowlevel\CleanerCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_cleanflexform extends \TYPO3\CMS\Lowlevel\CleanFlexformCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_deleted extends \TYPO3\CMS\Lowlevel\DeletedRecordsCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_double_files extends \TYPO3\CMS\Lowlevel\DoubleFilesCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_lost_files extends \TYPO3\CMS\Lowlevel\LostFilesCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_missing_files extends \TYPO3\CMS\Lowlevel\MissingFilesCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_missing_relations extends \TYPO3\CMS\Lowlevel\MissingRelationsCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_orphan_records extends \TYPO3\CMS\Lowlevel\OrphanRecordsCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_rte_images extends \TYPO3\CMS\Lowlevel\RteImagesCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_syslog extends \TYPO3\CMS\Lowlevel\SyslogCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_lowlevel_versions extends \TYPO3\CMS\Lowlevel\VersionsCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_arrayBrowser extends \TYPO3\CMS\Lowlevel\Utility\ArrayBrowser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_tools_config_index extends \TYPO3\CMS\Lowlevel\View\ConfigurationView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_tools_dbint_index extends \TYPO3\CMS\Lowlevel\View\DatabaseIntegrityView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_openid_eID extends \TYPO3\CMS\Openid\OpenidEid {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_openid_mod_setup extends \TYPO3\CMS\Openid\OpenidModuleSetup {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_openid_sv1 extends \TYPO3\CMS\Openid\OpenidService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_openid_store extends \TYPO3\CMS\Openid\OpenidStore {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_web_perm_ajax extends \TYPO3\CMS\Beuser\Controller\PermissionAjaxController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_web_perm_index extends \TYPO3\CMS\Beuser\Controller\PermissionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class browse_links extends \TYPO3\CMS\Recordlist\Browser\ElementBrowser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_browse_links extends \TYPO3\CMS\Recordlist\Controller\ElementBrowserController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_browser extends \TYPO3\CMS\Recordlist\Controller\ElementBrowserFramesetController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_db_list extends \TYPO3\CMS\Recordlist\RecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class recordList extends \TYPO3\CMS\Recordlist\RecordList\AbstractDatabaseRecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class localRecordList extends \TYPO3\CMS\Recordlist\RecordList\DatabaseRecordList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface localRecordList_actionsHook extends \TYPO3\CMS\Recordlist\RecordList\RecordListHookInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_view_deletedRecords extends \TYPO3\CMS\Recycler\Controller\DeletedRecordsController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_controller_ajax extends \TYPO3\CMS\Recycler\Controller\RecyclerAjaxController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_module1 extends \TYPO3\CMS\Recycler\Controller\RecyclerModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_model_deletedRecords extends \TYPO3\CMS\Recycler\Domain\Model\DeletedRecords {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_model_tables extends \TYPO3\CMS\Recycler\Domain\Model\Tables {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_recycler_helper extends \TYPO3\CMS\Recycler\Utility\RecyclerUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Reports_Controller_ReportController extends \TYPO3\CMS\Reports\Controller\ReportController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_ConfigurationStatus extends \TYPO3\CMS\Reports\Report\Status\ConfigurationStatus {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_SecurityStatus extends \TYPO3\CMS\Reports\Report\Status\SecurityStatus {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_Status extends \TYPO3\CMS\Reports\Report\Status\Status {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_Status extends \TYPO3\CMS\Reports\Status {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_SystemStatus extends \TYPO3\CMS\Reports\Report\Status\SystemStatus {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_Typo3Status extends \TYPO3\CMS\Reports\Report\Status\Typo3Status {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_reports_status_WarningMessagePostProcessor extends \TYPO3\CMS\Reports\Report\Status\WarningMessagePostProcessor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_reports_Report extends \TYPO3\CMS\Reports\ReportInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_reports_StatusProvider extends \TYPO3\CMS\Reports\StatusProviderInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_tasks_SystemStatusUpdateTask extends \TYPO3\CMS\Reports\Task\SystemStatusUpdateTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_reports_tasks_SystemStatusUpdateTaskNotificationEmailField extends \TYPO3\CMS\Reports\Task\SystemStatusUpdateTaskNotificationEmailField {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Reports_ViewHelpers_ActionMenuItemViewHelper extends \TYPO3\CMS\Reports\ViewHelpers\ActionMenuItemViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Reports_ViewHelpers_IconViewHelper extends \TYPO3\CMS\Reports\ViewHelpers\IconViewHelper {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_rsaauth_abstract_backend extends \TYPO3\CMS\Rsaauth\Backend\AbstractBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_backendfactory extends \TYPO3\CMS\Rsaauth\Backend\BackendFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_cmdline_backend extends \TYPO3\CMS\Rsaauth\Backend\CommandLineBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_php_backend extends \TYPO3\CMS\Rsaauth\Backend\PhpBackend {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_backendwarnings extends \TYPO3\CMS\Rsaauth\BackendWarnings {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_feloginhook extends \TYPO3\CMS\Rsaauth\Hook\FrontendLoginHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_usersetuphook extends \TYPO3\CMS\Rsaauth\Hook\UserSetupHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_keypair extends \TYPO3\CMS\Rsaauth\Keypair {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_sv1 extends \TYPO3\CMS\Rsaauth\RsaAuthService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_rsaauth_abstract_storage extends \TYPO3\CMS\Rsaauth\Storage\AbstractStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_session_storage extends \TYPO3\CMS\Rsaauth\Storage\SessionStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_split_storage extends \TYPO3\CMS\Rsaauth\Storage\SplitStorage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rsaauth_storagefactory extends \TYPO3\CMS\Rsaauth\Storage\StorageFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_browse_links extends \TYPO3\CMS\Rtehtmlarea\BrowseLinks {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_parse_html extends \TYPO3\CMS\Rtehtmlarea\Controller\ParseHtmlController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_SC_browse_links extends \TYPO3\CMS\Rtehtmlarea\Controller\BrowseLinksController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_pi3 extends \TYPO3\CMS\Rtehtmlarea\Controller\CustomAttributeController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_SC_select_image extends \TYPO3\CMS\Rtehtmlarea\Controller\SelectImageController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_pi1 extends \TYPO3\CMS\Rtehtmlarea\Controller\SpellCheckingController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_abouteditor extends \TYPO3\CMS\Rtehtmlarea\Extension\AboutEditor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_acronym extends \TYPO3\CMS\Rtehtmlarea\Extension\Abbreviation {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_blockelements extends \TYPO3\CMS\Rtehtmlarea\Extension\BlockElements {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_blockstyle extends \TYPO3\CMS\Rtehtmlarea\Extension\BlockStyle {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_charactermap extends \TYPO3\CMS\Rtehtmlarea\Extension\CharacterMap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_contextmenu extends \TYPO3\CMS\Rtehtmlarea\Extension\ContextMenu {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_copypaste extends \TYPO3\CMS\Rtehtmlarea\Extension\CopyPaste {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_defaultclean extends \TYPO3\CMS\Rtehtmlarea\Extension\DefaultClean {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_defaultimage extends \TYPO3\CMS\Rtehtmlarea\Extension\DefaultImage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_defaultinline extends \TYPO3\CMS\Rtehtmlarea\Extension\DefaultInline {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_defaultlink extends \TYPO3\CMS\Rtehtmlarea\Extension\DefaultLink {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_definitionlist extends \TYPO3\CMS\Rtehtmlarea\Extension\DefinitionList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_editelement extends \TYPO3\CMS\Rtehtmlarea\Extension\EditElement {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_editormode extends \TYPO3\CMS\Rtehtmlarea\Extension\EditorMode {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_findreplace extends \TYPO3\CMS\Rtehtmlarea\Extension\FindReplace {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_inlineelements extends \TYPO3\CMS\Rtehtmlarea\Extension\InlineElements {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_insertsmiley extends \TYPO3\CMS\Rtehtmlarea\Extension\InsertSmiley {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_language extends \TYPO3\CMS\Rtehtmlarea\Extension\Language {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_microdataschema extends \TYPO3\CMS\Rtehtmlarea\Extension\MicroDataSchema {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_plaintext extends \TYPO3\CMS\Rtehtmlarea\Extension\Plaintext {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_quicktag extends \TYPO3\CMS\Rtehtmlarea\Extension\QuickTag {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_removeformat extends \TYPO3\CMS\Rtehtmlarea\Extension\RemoveFormat {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_selectfont extends \TYPO3\CMS\Rtehtmlarea\Extension\SelectFont {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_spellchecker extends \TYPO3\CMS\Rtehtmlarea\Extension\Spellchecker {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_tableoperations extends \TYPO3\CMS\Rtehtmlarea\Extension\TableOperations {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_textindicator extends \TYPO3\CMS\Rtehtmlarea\Extension\TextIndicator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_textstyle extends \TYPO3\CMS\Rtehtmlarea\Extension\TextStyle {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_typo3color extends \TYPO3\CMS\Rtehtmlarea\Extension\Typo3Color {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_typo3htmlparser extends \TYPO3\CMS\Rtehtmlarea\Extension\Typo3HtmlParser {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_typo3image extends \TYPO3\CMS\Rtehtmlarea\Extension\Typo3Image {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_typo3link extends \TYPO3\CMS\Rtehtmlarea\Extension\Typo3Link {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_undoredo extends \TYPO3\CMS\Rtehtmlarea\Extension\UndoRedo {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_userelements extends \TYPO3\CMS\Rtehtmlarea\Extension\UserElements {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_folderTree extends \TYPO3\CMS\Rtehtmlarea\FolderTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_deprecatedRteProperties extends \TYPO3\CMS\Rtehtmlarea\Hook\Install\DeprecatedRteProperties {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_softrefproc extends \TYPO3\CMS\Rtehtmlarea\Hook\SoftReferenceHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_statusReport_conflictsCheck extends \TYPO3\CMS\Rtehtmlarea\Hook\StatusReportConflictsCheckHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_image_folderTree extends \TYPO3\CMS\Rtehtmlarea\FolderTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_pageTree extends \TYPO3\CMS\Rtehtmlarea\PageTree {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_api extends \TYPO3\CMS\Rtehtmlarea\RteHtmlAreaApi {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_select_image extends \TYPO3\CMS\Rtehtmlarea\SelectImage {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_rtehtmlarea_user extends \TYPO3\CMS\Rtehtmlarea\Controller\UserElementsController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_eval_be extends \TYPO3\CMS\Saltedpasswords\Evaluation\BackendEvaluator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_eval extends \TYPO3\CMS\Saltedpasswords\Evaluation\Evaluator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_eval_fe extends \TYPO3\CMS\Saltedpasswords\Evaluation\FrontendEvaluator {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_saltedpasswords_abstract_salts extends \TYPO3\CMS\Saltedpasswords\Salt\AbstractSalt {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_salts_blowfish extends \TYPO3\CMS\Saltedpasswords\Salt\BlowfishSalt {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_salts_md5 extends \TYPO3\CMS\Saltedpasswords\Salt\Md5Salt {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_salts_phpass extends \TYPO3\CMS\Saltedpasswords\Salt\PhpassSalt {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_salts_factory extends \TYPO3\CMS\Saltedpasswords\Salt\SaltFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_saltedpasswords_salts extends \TYPO3\CMS\Saltedpasswords\Salt\SaltInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_sv1 extends \TYPO3\CMS\Saltedpasswords\SaltedPasswordService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_Tasks_BulkUpdate_AdditionalFieldProvider extends \TYPO3\CMS\Saltedpasswords\Task\BulkUpdateFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_Tasks_BulkUpdate extends \TYPO3\CMS\Saltedpasswords\Task\BulkUpdateTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_emconfhelper extends \TYPO3\CMS\Saltedpasswords\Utility\ExtensionManagerConfigurationUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_saltedpasswords_div extends \TYPO3\CMS\Saltedpasswords\Utility\SaltedPasswordsUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_scheduler_AdditionalFieldProvider extends \TYPO3\CMS\Scheduler\AdditionalFieldProviderInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_Module extends \TYPO3\CMS\Scheduler\Controller\SchedulerModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_CronCmd extends \TYPO3\CMS\Scheduler\CronCommand\CronCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_CronCmd_Normalize extends \TYPO3\CMS\Scheduler\CronCommand\NormalizeCommand {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_SleepTask extends \TYPO3\CMS\Scheduler\Example\SleepTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_SleepTask_AdditionalFieldProvider extends \TYPO3\CMS\Scheduler\Example\SleepTaskAdditionalFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_Execution extends \TYPO3\CMS\Scheduler\Execution {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_FailedExecutionException extends \TYPO3\CMS\Scheduler\FailedExecutionException {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_scheduler_ProgressProvider extends \TYPO3\CMS\Scheduler\ProgressProviderInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler extends \TYPO3\CMS\Scheduler\Scheduler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_scheduler_Task extends \TYPO3\CMS\Scheduler\Task\AbstractTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_CachingFrameworkGarbageCollection_AdditionalFieldProvider extends \TYPO3\CMS\Scheduler\Task\CachingFrameworkGarbageCollectionAdditionalFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_CachingFrameworkGarbageCollection extends \TYPO3\CMS\Scheduler\Task\CachingFrameworkGarbageCollectionTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_RecyclerGarbageCollection_AdditionalFieldProvider extends \TYPO3\CMS\Scheduler\Task\RecyclerGarbageCollectionAdditionalFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_RecyclerGarbageCollection extends \TYPO3\CMS\Scheduler\Task\RecyclerGarbageCollectionTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_TableGarbageCollection_AdditionalFieldProvider extends \TYPO3\CMS\Scheduler\Task\TableGarbageCollectionAdditionalFieldProvider {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_scheduler_TableGarbageCollection extends \TYPO3\CMS\Scheduler\Task\TableGarbageCollectionTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_user_setup_index extends \TYPO3\CMS\Setup\Controller\SetupModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class tx_sv_authbase extends \TYPO3\CMS\Sv\AbstractAuthenticationService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_sv_auth extends \TYPO3\CMS\Sv\AuthenticationService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_sv_reports_ServicesList extends \TYPO3\CMS\Sv\Report\ServicesListReport {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_sysaction_list extends \TYPO3\CMS\SysAction\ActionList {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_sysaction_task extends \TYPO3\CMS\SysAction\ActionTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_t3editor_codecompletion extends \TYPO3\CMS\T3editor\CodeCompletion {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_t3editor_hooks_fileedit extends \TYPO3\CMS\T3editor\Hook\FileEditHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_t3editor_hooks_tstemplateinfo extends \TYPO3\CMS\T3editor\Hook\TypoScriptTemplateInfoHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_t3editor extends \TYPO3\CMS\T3editor\T3editor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_t3editor_TSrefLoader extends \TYPO3\CMS\T3editor\TypoScriptReferenceLoader {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_user_task_index extends \TYPO3\CMS\Taskcenter\Controller\TaskModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
interface tx_taskcenter_Task extends \TYPO3\CMS\Taskcenter\TaskInterface {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_taskcenter_status extends \TYPO3\CMS\Taskcenter\TaskStatus {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class SC_mod_web_ts_index extends \TYPO3\CMS\Tstemplate\Controller\TypoScriptTemplateModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_tstemplateanalyzer extends \TYPO3\CMS\Tstemplate\Controller\TemplateAnalyzerModuleFunctionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_tstemplateceditor extends \TYPO3\CMS\Tstemplate\Controller\TypoScriptTemplateConstantEditorModuleFunctionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_tstemplateinfo extends \TYPO3\CMS\Tstemplate\Controller\TypoScriptTemplateInformationModuleFunctionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_tstemplateobjbrowser extends \TYPO3\CMS\Tstemplate\Controller\TypoScriptTemplateObjectBrowserModuleFunctionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_cm1 extends \TYPO3\CMS\Version\Controller\VersionModuleController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_tcemain_CommandMap extends \TYPO3\CMS\Version\DataHandler\CommandMap {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_tcemain extends \TYPO3\CMS\Version\Hook\DataHandlerHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_iconworks extends \TYPO3\CMS\Version\Hook\IconUtilityHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_tasks_AutoPublish extends \TYPO3\CMS\Version\Task\AutoPublishTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Version_Preview extends \TYPO3\CMS\Version\Hook\PreviewHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_version_gui extends \TYPO3\CMS\Version\View\VersionView {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Dependency_Factory extends \TYPO3\CMS\Version\Dependency\DependencyEntityFactory {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Dependency extends \TYPO3\CMS\Version\Dependency\DependencyResolver {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Dependency_Element extends \TYPO3\CMS\Version\Dependency\ElementEntity {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Dependency_Callback extends \TYPO3\CMS\Version\Dependency\EventCallback {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class t3lib_utility_Dependency_Reference extends \TYPO3\CMS\Version\Dependency\ReferenceEntity {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class wslib extends \TYPO3\CMS\Version\Utility\WorkspacesUtility {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_wizardcrpages_webfunc_2 extends \TYPO3\CMS\WizardCrpages\Controller\CreatePagesWizardModuleFunctionController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class tx_wizardsortpages_webfunc_2 extends \TYPO3\CMS\WizardSortPages\View\SortPagesWizardModuleFunction {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Workspaces_Controller_AbstractController extends \TYPO3\CMS\Workspaces\Controller\AbstractController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Controller_PreviewController extends \TYPO3\CMS\Workspaces\Controller\PreviewController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Domain_Model_CombinedRecord extends \TYPO3\CMS\Workspaces\Domain\Model\CombinedRecord {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Domain_Model_DatabaseRecord extends \TYPO3\CMS\Workspaces\Domain\Model\DatabaseRecord {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Controller_ReviewController extends \TYPO3\CMS\Workspaces\Controller\ReviewController {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
abstract class Tx_Workspaces_ExtDirect_AbstractHandler extends \TYPO3\CMS\Workspaces\ExtDirect\AbstractHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_ExtDirect_ActionHandler extends \TYPO3\CMS\Workspaces\ExtDirect\ActionHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_ExtDirect_Server extends \TYPO3\CMS\Workspaces\ExtDirect\ExtDirectServer {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_ExtDirect_MassActionHandler extends \TYPO3\CMS\Workspaces\ExtDirect\MassActionHandler {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_ExtDirect_PagetreeCollectionsProcessor extends \TYPO3\CMS\Workspaces\ExtDirect\PagetreeCollectionsProcessor {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Befunc extends \TYPO3\CMS\Workspaces\Hook\BackendUtilityHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Tcemain extends \TYPO3\CMS\Workspaces\Hook\DataHandlerHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Fehooks extends \TYPO3\CMS\Workspaces\Hook\TypoScriptFrontendControllerHook {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_AutoPublish extends \TYPO3\CMS\Workspaces\Service\AutoPublishService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_GridData extends \TYPO3\CMS\Workspaces\Service\GridDataService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_History extends \TYPO3\CMS\Workspaces\Service\HistoryService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Integrity extends \TYPO3\CMS\Workspaces\Service\IntegrityService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Stages extends \TYPO3\CMS\Workspaces\Service\StagesService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_Workspaces extends \TYPO3\CMS\Workspaces\Service\WorkspaceService {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_AutoPublishTask extends \TYPO3\CMS\Workspaces\Task\AutoPublishTask {}

/**
 * @deprecated since 6.0, removed since 7.0
 */
class Tx_Workspaces_Service_CleanupPreviewLinkTask extends \TYPO3\CMS\Workspaces\Task\CleanupPreviewLinkTask {}

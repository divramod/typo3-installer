<?php
$MCONF['name'] = 'wizard_forms';
$MCONF['script'] = '_DISPATCH';
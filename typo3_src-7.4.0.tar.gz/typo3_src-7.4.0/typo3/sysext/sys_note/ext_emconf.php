<?php
$EM_CONF[$_EXTKEY] = array(
	'title' => 'Internal notes',
	'description' => 'Records with messages which can be placed on any page and contain instructions or other information related to a page or section.',
	'category' => 'be',
	'state' => 'stable',
	'uploadfolder' => 0,
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'author' => 'Kasper Skaarhoj',
	'author_email' => 'kasperYYYY@typo3.com',
	'author_company' => 'Curby Soft Multimedia',
	'version' => '7.4.0',
	'constraints' => array(
		'depends' => array(
			'typo3' => '7.4.0-7.4.99',
		),
		'conflicts' => array(),
		'suggests' => array(),
	),
);

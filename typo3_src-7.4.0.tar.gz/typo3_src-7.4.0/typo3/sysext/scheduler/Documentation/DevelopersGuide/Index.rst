﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt



.. _developer-guide:

Developer's Guide
-----------------

The Scheduler makes it very easy to create a new task class.
Furthermore the tasks packaged with this extension provide
a good basis to learn by example.


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   CreatingTasks/Index
   SchedulerApi/Index

